@echo off
setlocal

set PYTHON_EXE=C:\ProgramData\anaconda3\python.exe
set SCRIPT_DIR=%~dp0
set SCRIPT=%SCRIPT_DIR%recalculate_carbon_with_filled_landuse.py

"%PYTHON_EXE%" "%SCRIPT%"

endlocal
