# Carbon stock recalculation with filled 30 m landuse

This package contains the code and method notes used to recalculate 1 km mangrove carbon stock rasters for 2000, 2007, 2010, 2015, and 2020 after temporal imputation of the 30 m coastal land-use rasters.

## Contents

- `carbon_stock_filled_landuse/scripts/recalculate_carbon_with_filled_landuse.py`
  - Aggregates filled 30 m mangrove pixels to the existing 1 km panel grid.
  - Builds mangrove age/status weights from the 2000-2024 filled land-use history.
  - Uses Scientific Data carbon stock as the storage prior.
  - Applies nearest-neighbor storage-prior filling for current mangrove cells without valid Scientific Data carbon stock.
  - Normalizes annual output to conserve the Scientific Data annual total.
- `carbon_stock_filled_landuse/scripts/run_recalculate_carbon_with_filled_landuse_anaconda.bat`
  - Convenience runner using `C:\ProgramData\anaconda3\python.exe`.
- `carbon_stock_filled_landuse/docs/carbon_stock_filled_landuse_reallocation_method.md`
  - Formula and method description for the paper/method section.
- `carbon_stock_filled_landuse/reports/carbon_stock_filled_landuse_age_weighted_conservative_report.json`
  - Machine-readable summary of outputs, parameters, and validation.

## Main output directory

The generated rasters and tables were written to:

`E:\1红树林蓝碳\数据\yearly_panel_csv\coastal_1km_panel_2000_2024\carbon_stock_area_adjusted_nn\carbon_stock_filled_landuse_age_weighted_conservative`

The five carbon stock GeoTIFFs are in:

`...\tif_1km\carbon_stock_filled_landuse_age_weighted_conservative_{year}_1km_zlevel9.tif`

