# Filled-landuse mangrove carbon stock reallocation method

为解决 Scientific Data 红树林碳储量栅格与本研究 30 m 红树林分布在空间口径上的不一致问题，本研究采用基于辅助土地利用信息的总量守恒空间重分配方法。该方法借鉴 dasymetric mapping 思想，即利用土地覆盖等辅助信息对空间总量进行更合理的再分配（Mennis, 2003）；同时遵循 pycnophylactic interpolation 的总量守恒原则，即重分配后的空间单元加总值应与原始总量保持一致（Tobler, 1979）。

## 公式

设年份 \(t\) 中第 \(j\) 个 1 km 网格的当前红树林面积为：

\[
A_{j,t}=\sum_{p\in j} A_p \cdot M_{p,t}
\]

该网格的年龄加权红树林面积为：

\[
A^w_{j,t}=\sum_{p\in j} A_p \cdot M_{p,t}\cdot f(age_{p,t},status_{p,t})
\]

其中，\(p\) 表示位于第 \(j\) 个 1 km 网格内的第 \(p\) 个 30 m 像元；\(A_p\) 为单个 30 m 像元面积，本文中为 900 m²；\(M_{p,t}\) 表示像元 \(p\) 在年份 \(t\) 是否为红树林，若为红树林则取 1，否则取 0；\(age_{p,t}\) 为像元 \(p\) 截至年份 \(t\) 的连续红树林存在年限；\(status_{p,t}\) 表示红树林动态状态，包括持续存在、新增、恢复或消失；\(f(\cdot)\) 为年龄与状态权重函数。

为避免由于 Scientific Data 碳储量栅格与本研究 30 m 红树林分布在空间口径上不一致而产生异常碳密度，本文不直接使用“碳储量/红树林面积”构建碳密度，而是在储量层面构建空间分配先验。首先定义年龄-状态修正系数：

\[
G_{j,t}=
\begin{cases}
\dfrac{A^w_{j,t}}{A_{j,t}}, & A_{j,t}>0 \\
0, & A_{j,t}=0
\end{cases}
\]

随后构建第 \(j\) 个 1 km 网格在年份 \(t\) 的碳储量空间先验：

\[
S_{j,t}=
\begin{cases}
C^{SD}_{j,t}, & C^{SD}_{j,t}>0 \ \text{且} \ A_{j,t}>0 \\
C^{SD}_{NN(j),t}\cdot \dfrac{A_{j,t}}{A_0}, & C^{SD}_{j,t}\leq 0 \ \text{或缺失，且} \ A_{j,t}>0 \\
0, & A_{j,t}=0
\end{cases}
\]

其中，\(C^{SD}_{j,t}\) 表示 Scientific Data 中第 \(j\) 个 1 km 网格在年份 \(t\) 的原始红树林碳储量；\(NN(j)\) 表示距离第 \(j\) 个网格最近的、具有有效 Scientific Data 碳储量的 1 km 网格；\(C^{SD}_{NN(j),t}\) 为该最近邻网格的碳储量；\(A_0\) 为 1 km 网格面积，即 1 km²。若目标网格具有有效 Scientific Data 碳储量，则直接将该值作为空间先验；若目标网格被本研究识别为红树林但缺少有效 Scientific Data 碳储量，则采用最近邻有效碳储量网格作为先验，并按当前红树林面积占 1 km² 的比例进行折减。

在此基础上，构建第 \(j\) 个 1 km 网格在年份 \(t\) 的碳储量分配权重：

\[
W_{j,t}=S_{j,t}\cdot G_{j,t}
\]

最后，以 Scientific Data 年份 \(t\) 的红树林碳储量总量 \(C^{SD}_t\) 为约束，将年度总碳储量重分配至各 1 km 网格：

\[
C^*_{j,t}=C^{SD}_t\cdot
\dfrac{W_{j,t}}{\sum_{j=1}^{n}W_{j,t}}
\]

其中，\(C^*_{j,t}\) 为重分配后第 \(j\) 个 1 km 网格在年份 \(t\) 的红树林碳储量，\(n\) 为研究区内 1 km 网格总数。该方法满足年度总量守恒条件：

\[
\sum_{j=1}^{n}C^*_{j,t}=C^{SD}_t
\]

## 权重函数

参考红树林恢复和新生过程中的碳积累差异（Song et al., 2023），本文将年龄与状态权重函数定义为：

\[
f(age,status)=
\begin{cases}
1, & status=persistent \\
\min\left(\dfrac{age}{T},1\right), & status=regrowth \\
\rho\cdot \min\left(\dfrac{age}{T},1\right), & status=new \\
0, & status=loss
\end{cases}
\]

其中，\(persistent\) 表示持续存在的红树林，权重设为 1；\(regrowth\) 表示曾经消失后恢复的红树林，其碳储量承载能力随连续存在年限增加，并在达到参考成熟年限 \(T\) 后趋于稳定；\(new\) 表示新增红树林，由于其碳积累能力低于恢复红树林，因此在相同年龄条件下乘以折减系数 \(\rho\)；\(loss\) 表示目标年份已消失的红树林，不再参与当年红树林碳储量分配，权重设为 0。

本文参考 Song et al. (2023) 关于红树林 reforestation 与 afforestation 碳收益差异的研究，将参考成熟年限 \(T\) 设为 40 年。Song et al. (2023) 指出，在 40 年尺度上，reforestation 的碳收益约比 afforestation 高 60%，因此本文将新增红树林相对于恢复红树林的折减系数设为：

\[
\rho=\dfrac{1}{1.6}=0.625
\]

由于本研究逐年 30 m 土地利用数据的起始年份为 2000 年，2000 年以前红树林的存在历史和林龄无法被直接观测。因此，本文将 2000 年基准期已存在的红树林视为存量红树林，并假定其已达到或接近成熟碳储量水平，在年龄-状态权重函数中赋予权重 1。2000 年以后新增或恢复的红树林则进入 40 年年龄累积过程。

## References

- Mennis, J. (2003). Generating surface models of population using dasymetric mapping. The Professional Geographer.
- Tobler, W. R. (1979). Smooth pycnophylactic interpolation for geographical regions.
- Song et al. (2023). Mangrove reforestation provides greater blue carbon benefit than afforestation for mitigating global climate change. Nature Communications.
- Hamilton and Friess (2018). Global carbon stocks and potential emissions due to mangrove deforestation from 2000 to 2012. Nature Climate Change.
- Donato et al. (2011). Mangroves among the most carbon-rich forests in the tropics. Nature Geoscience.
