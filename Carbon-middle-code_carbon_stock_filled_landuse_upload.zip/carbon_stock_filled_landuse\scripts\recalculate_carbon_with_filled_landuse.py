from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import rasterio
from pyproj import Transformer
from rasterio.windows import Window
from scipy.spatial import cKDTree


BASE = Path("E:/1\u7ea2\u6811\u6797\u84dd\u78b3/\u6570\u636e/yearly_panel_csv/coastal_1km_panel_2000_2024")
NN_DIR = BASE / "carbon_stock_area_adjusted_nn"

PANEL = BASE / "coastal_1km_panel_2000_2024.parquet"
RECOMMENDED = (
    NN_DIR
    / "carbon_stock_nn_recommended_direct_preserve_nearest_fraction_1km_2000_2007_2010_2015_2020.parquet"
)
MASK_1KM = Path("E:/1\u7ea2\u6811\u6797\u84dd\u78b3/\u6570\u636e/\u6c14\u6e29/\u6cbf\u6d77\u571f\u5730\u5229\u752825\u5e74\u5e76\u96c6\u63a9\u819c/1km\u5e76\u96c6\u63a9\u819c.tif")
FILLED_LANDUSE_DIR = Path(
    "E:/1\u7ea2\u6811\u6797\u84dd\u78b3/\u6570\u636e/"
    "\u6cbf\u6d77\u571f\u5730\u8986\u88ab\u56fe\uff0810km\u7f13\u51b2\uff09/"
    "\u571f\u5730\u5229\u7528\u56fe_\u65f6\u95f4\u5e8f\u5217\u586b\u886530m/"
    "filled_landuse_tif"
)

OUT_DIR = NN_DIR / "carbon_stock_filled_landuse_age_weighted_conservative"
OUT_TIF_DIR = OUT_DIR / "tif_1km"
OUT_AREA_PARQUET = OUT_DIR / "mangrove_area_filled_landuse_30m_by_1km_grid_2000_2024.parquet"
OUT_DETAIL = OUT_DIR / "carbon_stock_filled_landuse_age_weighted_conservative_1km_2000_2007_2010_2015_2020.parquet"
OUT_XLSX = OUT_DIR / "carbon_stock_filled_landuse_age_weighted_conservative_summary.xlsx"
OUT_JSON = OUT_DIR / "carbon_stock_filled_landuse_age_weighted_conservative_report.json"

ALL_YEARS = list(range(2000, 2025))
TARGET_YEARS = [2000, 2007, 2010, 2015, 2020]

MANGROVE_CODE = 11
PIXEL_AREA_M2 = 900.0
PIXEL_AREA_KM2 = PIXEL_AREA_M2 / 1_000_000.0
MATURE_YEARS = 40.0
NEW_STAND_RELATIVE_FACTOR = 1.0 / 1.6
NODATA = -9999.0
TILE = 4096

STATUS_LABELS = {
    0: "no_current_mangrove",
    1: "persistent_since_2000",
    2: "new_after_2000",
    3: "regrowth_after_gap",
    4: "lost_by_target_year",
}


def landuse_path(year: int) -> Path:
    return FILLED_LANDUSE_DIR / f"coastal_landuse_30m_temporal_filled_{year}_albers.tif"


def require_inputs() -> None:
    paths = [PANEL, RECOMMENDED, MASK_1KM]
    paths.extend(landuse_path(year) for year in ALL_YEARS)
    missing = [p for p in paths if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required input(s):\n" + "\n".join(map(str, missing)))


def make_windows(width: int, height: int, tile: int = TILE) -> list[Window]:
    windows: list[Window] = []
    for row_off in range(0, height, tile):
        h = min(tile, height - row_off)
        for col_off in range(0, width, tile):
            w = min(tile, width - col_off)
            windows.append(Window(col_off, row_off, w, h))
    return windows


def load_panel_grids(width: int, height: int) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    table = pq.read_table(PANEL, columns=["year", "grid_id", "row", "col", "protect", "type"])
    df = table.to_pandas()
    base = df[df["year"] == 2000].copy()
    protect_grid = np.full((height, width), -1, dtype=np.int16)
    type_grid = np.zeros((height, width), dtype=np.int16)
    rows = base["row"].to_numpy(np.int64)
    cols = base["col"].to_numpy(np.int64)
    protect_grid[rows, cols] = base["protect"].to_numpy(np.int16)
    type_grid[rows, cols] = base["type"].to_numpy(np.int16)
    return protect_grid, type_grid, base


def count_mangrove_year(
    year: int,
    ref: rasterio.io.DatasetReader,
    protect_grid: np.ndarray,
    type_grid: np.ndarray,
) -> tuple[dict[str, object], pd.DataFrame]:
    path = landuse_path(year)
    start = time.time()
    total_count = 0
    assigned_count = 0
    flat_counts: dict[int, int] = {}

    with rasterio.open(path) as src:
        transformer = Transformer.from_crs(src.crs, ref.crs, always_xy=True)
        src_transform = src.transform
        ref_transform = ref.transform
        ref_width = ref.width
        ref_height = ref.height
        windows = make_windows(src.width, src.height)
        for idx, window in enumerate(windows, start=1):
            data = src.read(1, window=window, masked=False)
            rr, cc = np.nonzero(data == MANGROVE_CODE)
            if rr.size == 0:
                continue

            total_count += int(rr.size)
            src_cols = cc.astype(np.float64) + float(window.col_off) + 0.5
            src_rows = rr.astype(np.float64) + float(window.row_off) + 0.5
            xs = src_transform.c + src_cols * src_transform.a + src_rows * src_transform.b
            ys = src_transform.f + src_cols * src_transform.d + src_rows * src_transform.e
            tx, ty = transformer.transform(xs, ys)

            ref_cols = np.floor((tx - ref_transform.c) / ref_transform.a).astype(np.int64)
            ref_rows = np.floor((ty - ref_transform.f) / ref_transform.e).astype(np.int64)
            inside = (ref_rows >= 0) & (ref_rows < ref_height) & (ref_cols >= 0) & (ref_cols < ref_width)
            if not np.any(inside):
                continue

            ref_rows = ref_rows[inside]
            ref_cols = ref_cols[inside]
            valid = protect_grid[ref_rows, ref_cols] >= 0
            if not np.any(valid):
                continue

            ref_rows = ref_rows[valid]
            ref_cols = ref_cols[valid]
            assigned_count += int(ref_rows.size)

            flat = ref_rows * ref_width + ref_cols
            unique, counts = np.unique(flat, return_counts=True)
            for k, v in zip(unique.tolist(), counts.tolist()):
                flat_counts[k] = flat_counts.get(k, 0) + int(v)

            if idx % 100 == 0:
                print(f"  {year}: {idx}/{len(windows)} windows, mangrove30m={total_count}", flush=True)

    if flat_counts:
        flats = np.fromiter(flat_counts.keys(), dtype=np.int64)
        counts = np.fromiter(flat_counts.values(), dtype=np.int32)
        rows = flats // ref.width
        cols = flats % ref.width
        grid_df = pd.DataFrame(
            {
                "grid_id": flats + 1,
                "year": np.int16(year),
                "row": rows.astype(np.int32),
                "col": cols.astype(np.int32),
                "protect": protect_grid[rows, cols].astype(np.int16),
                "type": type_grid[rows, cols].astype(np.int16),
                "mangrove_30m_pixel_count": counts,
                "mangrove_area_km2": counts.astype(np.float64) * PIXEL_AREA_KM2,
                "mangrove_area_m2": counts.astype(np.float64) * PIXEL_AREA_M2,
            }
        ).sort_values("grid_id")
    else:
        grid_df = pd.DataFrame(
            columns=[
                "grid_id",
                "year",
                "row",
                "col",
                "protect",
                "type",
                "mangrove_30m_pixel_count",
                "mangrove_area_km2",
                "mangrove_area_m2",
            ]
        )

    summary = {
        "year": year,
        "mangrove_landuse_code": MANGROVE_CODE,
        "mangrove_30m_pixel_count": int(total_count),
        "mangrove_area_km2": float(total_count * PIXEL_AREA_KM2),
        "assigned_to_1km_panel_pixel_count": int(assigned_count),
        "unassigned_30m_pixel_count": int(total_count - assigned_count),
        "positive_1km_cells": int(len(grid_df)),
        "source_landuse": str(path),
        "elapsed_sec": round(time.time() - start, 2),
    }
    return summary, grid_df


def build_filled_mangrove_area_table() -> tuple[pd.DataFrame, pd.DataFrame]:
    print("Aggregating filled 30 m mangrove pixels to the 1 km panel grid...", flush=True)
    with rasterio.open(MASK_1KM) as ref:
        protect_grid, type_grid, _ = load_panel_grids(ref.width, ref.height)
        summaries: list[dict[str, object]] = []
        tables: list[pa.Table] = []
        for year in ALL_YEARS:
            print(f"Year {year}: counting filled-landuse mangrove pixels...", flush=True)
            summary, grid_df = count_mangrove_year(year, ref, protect_grid, type_grid)
            summaries.append(summary)
            tables.append(pa.Table.from_pandas(grid_df, preserve_index=False))
            print(
                f"Year {year}: area={summary['mangrove_area_km2']:.4f} km2, "
                f"positive_1km_cells={summary['positive_1km_cells']}, "
                f"unassigned_pixels={summary['unassigned_30m_pixel_count']}",
                flush=True,
            )

    area_df = pa.concat_tables(tables).to_pandas()
    return pd.DataFrame(summaries), area_df


def consecutive_present_age(present: np.ndarray) -> np.ndarray:
    rev = present[:, ::-1]
    no_gap = rev.all(axis=1)
    first_gap_from_end = np.argmax(~rev, axis=1)
    age = np.where(no_gap, present.shape[1], first_gap_from_end).astype(np.float32)
    age[~present[:, -1]] = 0.0
    return age


def prior_positive_before_current_spell(present: np.ndarray, age: np.ndarray) -> np.ndarray:
    start_idx = (present.shape[1] - age).astype(np.int32)
    csum = present.cumsum(axis=1)
    out = np.zeros(present.shape[0], dtype=bool)
    rows = np.where(start_idx > 0)[0]
    if rows.size:
        out[rows] = csum[rows, start_idx[rows] - 1] > 0
    return out


def build_age_weights(
    area_matrix: np.ndarray, grid_pos: np.ndarray, year: int
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    year_index = ALL_YEARS.index(year)
    hist = area_matrix[grid_pos, : year_index + 1].astype(np.float64, copy=False)
    current_area = hist[:, -1]
    present = hist > 0
    current_present = current_area > 0

    age = consecutive_present_age(present)
    had_prior_positive = prior_positive_before_current_spell(present, age)
    persistent = current_present & present.all(axis=1)
    new = current_present & (~persistent) & (~had_prior_positive)
    regrowth = current_present & (~persistent) & had_prior_positive
    lost = (~current_present) & present.any(axis=1)

    status = np.zeros(hist.shape[0], dtype=np.uint8)
    status[persistent] = 1
    status[new] = 2
    status[regrowth] = 3
    status[lost] = 4

    persistent_area = np.zeros(hist.shape[0], dtype=np.float64)
    if persistent.any():
        persistent_area[persistent] = np.minimum(hist[persistent].min(axis=1), current_area[persistent])

    residual_area = np.maximum(current_area - persistent_area, 0.0)
    age_factor = np.minimum(age / MATURE_YEARS, 1.0)

    residual_factor = np.zeros(hist.shape[0], dtype=np.float64)
    residual_factor[persistent | new] = NEW_STAND_RELATIVE_FACTOR * age_factor[persistent | new]
    residual_factor[regrowth] = age_factor[regrowth]

    weighted_area = persistent_area + residual_area * residual_factor
    effective_weight = np.zeros(hist.shape[0], dtype=np.float64)
    has_current = current_area > 0
    effective_weight[has_current] = weighted_area[has_current] / current_area[has_current]
    return status, age, effective_weight, weighted_area, persistent_area


def build_storage_prior(sub: pd.DataFrame, current_area: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    raw = sub["carbon_stock_scidata_raw"].fillna(0).clip(lower=0).to_numpy(np.float64)
    has_current = current_area > 0
    has_raw = raw > 0
    direct = has_current & has_raw
    fill = has_current & (~has_raw)

    prior = np.zeros(len(sub), dtype=np.float64)
    source_grid = np.full(len(sub), -1, dtype=np.int64)
    source_distance = np.full(len(sub), np.nan, dtype=np.float64)
    source_stock = np.full(len(sub), np.nan, dtype=np.float64)

    prior[direct] = raw[direct]
    source_grid[direct] = sub.loc[direct, "grid_id"].to_numpy(np.int64)
    source_distance[direct] = 0.0
    source_stock[direct] = raw[direct]

    if fill.any():
        if not has_raw.any():
            raise ValueError(f"Year {int(sub['year'].iloc[0])}: no positive Scientific Data carbon cells.")
        source_xy = sub.loc[has_raw, ["x", "y"]].to_numpy(np.float64)
        source_raw = raw[has_raw]
        source_ids = sub.loc[has_raw, "grid_id"].to_numpy(np.int64)
        tree = cKDTree(source_xy)
        target_xy = sub.loc[fill, ["x", "y"]].to_numpy(np.float64)
        dist, idx = tree.query(target_xy, k=1)
        fill_indices = np.where(fill)[0]
        donor_stock = source_raw[idx]
        prior[fill_indices] = donor_stock * current_area[fill_indices]
        source_grid[fill_indices] = source_ids[idx]
        source_distance[fill_indices] = dist
        source_stock[fill_indices] = donor_stock

    return prior, source_grid, source_distance, source_stock


def write_tif(template_profile: dict, values: pd.DataFrame, value_col: str, out_path: Path) -> float:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    profile = template_profile.copy()
    profile.update(
        driver="GTiff",
        count=1,
        dtype="float32",
        nodata=NODATA,
        compress="deflate",
        predictor=3,
        zlevel=9,
        tiled=True,
        blockxsize=256,
        blockysize=256,
        BIGTIFF="IF_SAFER",
    )

    height, width = profile["height"], profile["width"]
    arr = np.full((height, width), NODATA, dtype=np.float32)
    rows = values["row"].to_numpy(np.int64)
    cols = values["col"].to_numpy(np.int64)
    valid = (rows >= 0) & (rows < height) & (cols >= 0) & (cols < width)
    if valid.sum() != len(values):
        raise ValueError(f"{out_path.name}: {len(values) - valid.sum()} rows fall outside template raster.")
    arr[rows, cols] = values[value_col].fillna(0).to_numpy(np.float32)

    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(arr, 1)

    return float(arr[arr != NODATA].sum(dtype=np.float64))


def main() -> None:
    t0 = time.time()
    require_inputs()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    OUT_TIF_DIR.mkdir(parents=True, exist_ok=True)

    area_summary_df, area_df = build_filled_mangrove_area_table()
    pq.write_table(pa.Table.from_pandas(area_df, preserve_index=False), OUT_AREA_PARQUET, compression="zstd")
    print(f"Saved filled-landuse mangrove area parquet: {OUT_AREA_PARQUET}", flush=True)

    print("Reading Scientific Data / 1 km panel matching table...", flush=True)
    recommended = pd.read_parquet(RECOMMENDED, engine="pyarrow")
    recommended = recommended[recommended["year"].isin(TARGET_YEARS)].copy()
    recommended.sort_values(["year", "grid_id"], inplace=True, kind="stable")

    grid_ids = recommended["grid_id"].drop_duplicates().sort_values().to_numpy()
    grid_lookup = pd.Series(np.arange(grid_ids.size, dtype=np.int64), index=grid_ids)

    area_pivot = area_df.pivot_table(
        index="grid_id", columns="year", values="mangrove_area_km2", aggfunc="sum"
    )
    for year in ALL_YEARS:
        if year not in area_pivot.columns:
            area_pivot[year] = 0.0
    area_pivot = area_pivot.reindex(grid_ids).fillna(0.0)
    area_matrix = area_pivot[ALL_YEARS].to_numpy(np.float32, copy=True)
    del area_pivot

    detail_parts: list[pd.DataFrame] = []
    year_summary: list[dict[str, object]] = []
    status_summary: list[dict[str, object]] = []

    print("Computing filled-landuse age-weighted conservative carbon allocation...", flush=True)
    for year in TARGET_YEARS:
        sub = recommended[recommended["year"] == year].copy()
        grid_pos = grid_lookup.loc[sub["grid_id"].to_numpy()].to_numpy()
        current_area = area_matrix[grid_pos, ALL_YEARS.index(year)].astype(np.float64, copy=False)

        status, age, eff_weight, weighted_area, persistent_area = build_age_weights(
            area_matrix, grid_pos, year
        )
        prior, source_grid, source_distance, source_stock = build_storage_prior(sub, current_area)
        spatial_weight = prior * eff_weight

        target_total = float(
            sub["carbon_stock_scidata_raw"].fillna(0).clip(lower=0).to_numpy(np.float64).sum(dtype=np.float64)
        )
        initial_sum = float(spatial_weight.sum(dtype=np.float64))
        if initial_sum <= 0:
            raise ValueError(f"Year {year}: spatial weights sum to zero.")
        scale = target_total / initial_sum
        carbon_out = spatial_weight * scale

        sub["mangrove_area_km2_filled_landuse"] = current_area
        sub["mangrove_age_status"] = status
        sub["mangrove_age_status_label"] = pd.Series(status, index=sub.index).map(STATUS_LABELS)
        sub["mangrove_continuous_age_years"] = age
        sub["mangrove_persistent_area_km2_proxy"] = persistent_area
        sub["mangrove_age_weighted_area_km2"] = weighted_area
        sub["mangrove_age_effective_weight"] = eff_weight
        sub["carbon_storage_prior_filled_landuse"] = prior
        sub["carbon_storage_prior_source_grid_id"] = source_grid
        sub["carbon_storage_prior_source_distance_m"] = source_distance
        sub["carbon_storage_prior_source_raw_stock"] = source_stock
        sub["carbon_stock_filled_landuse_spatial_weight"] = spatial_weight
        sub["carbon_stock_filled_landuse_scale_factor"] = scale
        sub["carbon_stock_filled_landuse_age_weighted_conservative"] = carbon_out
        sub["carbon_stock_scidata_panel_total_by_year"] = target_total

        has_current = current_area > 0
        has_raw = sub["carbon_stock_scidata_raw"].fillna(0).to_numpy(np.float64) > 0
        out_total = float(carbon_out.sum(dtype=np.float64))
        year_summary.append(
            {
                "year": year,
                "scidata_total": target_total,
                "initial_weight_sum": initial_sum,
                "scale_factor": scale,
                "output_total": out_total,
                "output_minus_scidata_total": out_total - target_total,
                "current_mangrove_area_km2_filled_landuse": float(current_area.sum(dtype=np.float64)),
                "age_weighted_mangrove_area_km2": float(weighted_area.sum(dtype=np.float64)),
                "current_mangrove_cells": int(has_current.sum()),
                "direct_scidata_prior_cells": int((has_current & has_raw).sum()),
                "nearest_neighbor_prior_cells": int((has_current & (~has_raw)).sum()),
                "scidata_positive_without_current_mangrove_cells": int(((~has_current) & has_raw).sum()),
                "elapsed_min": round((time.time() - t0) / 60.0, 3),
            }
        )

        for code, label in STATUS_LABELS.items():
            m = status == code
            status_summary.append(
                {
                    "year": year,
                    "status": code,
                    "status_label": label,
                    "cell_count": int(m.sum()),
                    "mangrove_area_km2": float(current_area[m].sum(dtype=np.float64)),
                    "persistent_area_km2_proxy": float(persistent_area[m].sum(dtype=np.float64)),
                    "age_weighted_area_km2": float(weighted_area[m].sum(dtype=np.float64)),
                    "carbon_stock_filled_landuse_age_weighted_conservative": float(carbon_out[m].sum(dtype=np.float64)),
                    "mean_effective_weight": float(np.nanmean(eff_weight[m])) if m.any() else np.nan,
                    "mean_continuous_age_years": float(np.nanmean(age[m])) if m.any() else np.nan,
                }
            )

        detail_parts.append(sub)
        print(
            f"  {year}: target={target_total:.6f}, output={out_total:.6f}, "
            f"scale={scale:.6f}, mangrove_cells={int(has_current.sum())}, "
            f"nn_prior_cells={int((has_current & (~has_raw)).sum())}",
            flush=True,
        )

    detail = pd.concat(detail_parts, ignore_index=True)
    detail.to_parquet(OUT_DETAIL, index=False, engine="pyarrow", compression="zstd")
    print(f"Saved detail parquet: {OUT_DETAIL}", flush=True)

    print("Writing 1 km GeoTIFF outputs...", flush=True)
    tif_validation: list[dict[str, object]] = []
    with rasterio.open(MASK_1KM) as template:
        template_profile = template.profile.copy()
        for year in TARGET_YEARS:
            year_df = detail[detail["year"] == year]
            carbon_tif = OUT_TIF_DIR / f"carbon_stock_filled_landuse_age_weighted_conservative_{year}_1km_zlevel9.tif"
            area_tif = OUT_TIF_DIR / f"mangrove_age_weighted_area_filled_landuse_{year}_1km_zlevel9.tif"
            carbon_sum = write_tif(
                template_profile,
                year_df,
                "carbon_stock_filled_landuse_age_weighted_conservative",
                carbon_tif,
            )
            area_sum = write_tif(template_profile, year_df, "mangrove_age_weighted_area_km2", area_tif)
            table_sum = float(year_df["carbon_stock_filled_landuse_age_weighted_conservative"].sum())
            tif_validation.append(
                {
                    "year": year,
                    "carbon_tif": str(carbon_tif),
                    "carbon_tif_sum": carbon_sum,
                    "carbon_table_sum": table_sum,
                    "carbon_tif_minus_table": carbon_sum - table_sum,
                    "age_weighted_area_tif": str(area_tif),
                    "age_weighted_area_tif_sum": area_sum,
                    "age_weighted_area_table_sum": float(year_df["mangrove_age_weighted_area_km2"].sum()),
                }
            )
            print(f"  wrote {carbon_tif.name}; tif_sum={carbon_sum:.6f}", flush=True)

    year_summary_df = pd.DataFrame(year_summary)
    status_summary_df = pd.DataFrame(status_summary)
    tif_validation_df = pd.DataFrame(tif_validation)
    params_df = pd.DataFrame(
        [
            {"parameter": "filled_landuse_dir", "value": str(FILLED_LANDUSE_DIR)},
            {"parameter": "mangrove_landuse_code", "value": MANGROVE_CODE},
            {"parameter": "target_years", "value": ",".join(map(str, TARGET_YEARS))},
            {"parameter": "all_history_years", "value": f"{ALL_YEARS[0]}-{ALL_YEARS[-1]}"},
            {"parameter": "mature_years_T", "value": MATURE_YEARS},
            {"parameter": "new_stand_relative_factor_rho", "value": NEW_STAND_RELATIVE_FACTOR},
            {"parameter": "output_resolution_m", "value": 1000},
            {"parameter": "output_template", "value": str(MASK_1KM)},
            {"parameter": "spatial_prior", "value": "direct Scientific Data stock; nearest-neighbor raw stock * current filled-landuse mangrove area for missing carbon cells"},
            {"parameter": "conservation_rule", "value": "annual output sum equals annual Scientific Data total"},
        ]
    )

    with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as writer:
        year_summary_df.to_excel(writer, sheet_name="year_summary", index=False)
        status_summary_df.to_excel(writer, sheet_name="status_by_year", index=False)
        area_summary_df.to_excel(writer, sheet_name="filled_mangrove_area", index=False)
        tif_validation_df.to_excel(writer, sheet_name="tif_validation", index=False)
        params_df.to_excel(writer, sheet_name="parameters", index=False)

    report = {
        "detail_parquet": str(OUT_DETAIL),
        "area_parquet": str(OUT_AREA_PARQUET),
        "summary_xlsx": str(OUT_XLSX),
        "tif_dir": str(OUT_TIF_DIR),
        "parameters": {
            "mangrove_landuse_code": MANGROVE_CODE,
            "target_years": TARGET_YEARS,
            "all_history_years": ALL_YEARS,
            "mature_years_T": MATURE_YEARS,
            "new_stand_relative_factor_rho": NEW_STAND_RELATIVE_FACTOR,
            "spatial_prior": "storage-prior conservative reallocation using filled 30 m landuse",
        },
        "filled_landuse_mangrove_area_summary": area_summary_df.to_dict(orient="records"),
        "year_summary": year_summary,
        "status_summary": status_summary,
        "tif_validation": tif_validation,
    }
    OUT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Saved summary xlsx: {OUT_XLSX}", flush=True)
    print(f"Saved json report: {OUT_JSON}", flush=True)
    print(f"Done in {(time.time() - t0) / 60.0:.2f} min", flush=True)


if __name__ == "__main__":
    main()
