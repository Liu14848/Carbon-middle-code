# HAND Nearest-Neighbor Fill

This package contains only the code, report, and process note for `hand_m` nearest-neighbor filling.

Large GeoTIFF outputs are not included. See `docs/hand_nearest_fill.md` and the report files for
output paths.
