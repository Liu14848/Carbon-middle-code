# Environmental raster nearest-neighbor imputation

This folder records the nearest-neighbor imputation for four continuous environmental raster variables
used by the coastal mangrove panel:

- annual PM2.5 (`pm25`)
- coldest-month mean temperature (`coldest_month_temp`)
- driest-month precipitation (`driest_month_precip`)
- annual potential evapotranspiration (`pet_annual_mm`)

## Method

For each variable and year from 2000 to 2024:

1. Match the source raster to the corresponding coastal union mask.
2. Define source cells as valid pixels inside the mask.
3. Define target cells as NoData pixels inside the mask.
4. Fill each target cell with the value of its nearest valid source cell.
5. Compute nearest-neighbor distances in the project Albers CRS.
6. Leave pixels outside the study mask unchanged.

The scripts write new GeoTIFFs next to the original rasters using the suffix:

`_nearest_filled.tif`

Original rasters are not overwritten. Large GeoTIFF outputs are intentionally not stored in this code
repository; the reports record the local input and output paths.

## Script

- `scripts/fill_environment_rasters_nearest.py`

Required Python packages: `numpy`, `pandas`, `pyarrow`, `rasterio`, `pyproj`, and `scipy`.
The script was run with `C:/ProgramData/anaconda3/python.exe`.

## Summary

| variable | files | missing before | filled | missing after | max nearest distance (m) |
|---|---:|---:|---:|---:|---:|
| coldest_month_temp | 25 | 925975 | 925975 | 0 | 32899.18 |
| driest_month_precip | 25 | 925975 | 925975 | 0 | 32899.18 |
| pet_annual_mm | 25 | 461200 | 461200 | 0 | 28933.04 |
| pm25 | 25 | 885143 | 885143 | 0 | 33797.97 |

## Reports

- `reports/environment_nearest_fill_report.csv`: file-level fill statistics and output paths.
- `reports/environment_nearest_fill_report.json`: full JSON report from the processing script.
