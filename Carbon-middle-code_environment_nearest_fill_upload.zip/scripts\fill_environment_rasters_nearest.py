from __future__ import annotations

import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from pyproj import Transformer
from rasterio.enums import Resampling
from rasterio.warp import reproject
from scipy.spatial import cKDTree


BASE = Path("E:/1红树林蓝碳/数据")
YEARS = list(range(2000, 2025))
SUFFIX = "_nearest_filled"

ALBERS_MASK = BASE / "气温/沿海土地利用25年并集掩膜/1km并集掩膜.tif"
TEMP_PRECIP_MASK = (
    BASE
    / "气温/沿海土地利用25年并集掩膜/"
    "coastal_landuse_2000_2024_union_any_valid_on_temperature_grid_7849x5146_0p00833333x0p00833333.tif"
)
PM25_MASK = (
    BASE
    / "PM2.5/PM25沿海并集裁剪/coastal_landuse_union_any_valid_on_CHAP_PM25_0p01deg_grid.tif"
)

PM25_DIR = BASE / "PM2.5/PM25沿海并集裁剪"
TEMP_DIR = BASE / "气温/最冷月平均气温_沿海并集裁剪后"
PRECIP_DIR = BASE / "降水/降水量沿海并集裁剪_干旱胁迫"
PET_DIR = BASE / "潜在蒸散发/pet_annual_coastal_union_clip"

REPORT_DIR = BASE / "yearly_panel_csv/coastal_1km_panel_2000_2024"
REPORT_JSON = REPORT_DIR / "environment_nearest_fill_report.json"
REPORT_CSV = REPORT_DIR / "environment_nearest_fill_report.csv"


def output_path(src: Path) -> Path:
    return src.with_name(f"{src.stem}{SUFFIX}{src.suffix}")


def pm25_path(year: int) -> Path:
    return PM25_DIR / f"1km任意覆盖并集边界裁剪_CHAP_PM2.5_Y1K_{year}_V4_coastal_union_clip.tif"


def temp_path(year: int) -> Path:
    return TEMP_DIR / f"1km任意覆盖并集裁剪_coldest_month_mean_temperature_{year}_coastal_union_clip.tif"


def precip_path(year: int) -> Path:
    return PRECIP_DIR / f"1km任意覆盖并集裁剪_driest_month_precipitation_{year}_coastal_union_clip.tif"


def pet_path(year: int) -> Path:
    return PET_DIR / f"pet_{year}_annual_mm_coastal_union_zlevel9.tif"


DATASETS = [
    {
        "variable": "pm25",
        "description": "annual PM2.5",
        "path_func": pm25_path,
        "mask": PM25_MASK,
    },
    {
        "variable": "coldest_month_temp",
        "description": "coldest-month mean temperature",
        "path_func": temp_path,
        "mask": TEMP_PRECIP_MASK,
    },
    {
        "variable": "driest_month_precip",
        "description": "driest-month precipitation",
        "path_func": precip_path,
        "mask": TEMP_PRECIP_MASK,
    },
    {
        "variable": "pet_annual_mm",
        "description": "annual potential evapotranspiration",
        "path_func": pet_path,
        "mask": ALBERS_MASK,
    },
]


def require_inputs() -> None:
    paths: list[Path] = [ALBERS_MASK, TEMP_PRECIP_MASK, PM25_MASK]
    for dataset in DATASETS:
        paths.extend(dataset["path_func"](year) for year in YEARS)
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required input(s):\n" + "\n".join(map(str, missing)))


def raster_valid(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    if np.issubdtype(arr.dtype, np.floating):
        valid = np.isfinite(arr)
        if nodata is not None and np.isfinite(float(nodata)):
            valid &= arr != nodata
        valid &= arr > -9000
        valid &= arr < 1.0e30
        return valid
    if nodata is not None:
        return arr != np.array(nodata, dtype=arr.dtype)
    return np.ones(arr.shape, dtype=bool)


def same_grid(src: rasterio.DatasetReader, mask_src: rasterio.DatasetReader) -> bool:
    return (
        src.width == mask_src.width
        and src.height == mask_src.height
        and src.crs == mask_src.crs
        and src.transform.almost_equals(mask_src.transform)
    )


def load_mask_for_source(src: rasterio.DatasetReader, mask_path: Path) -> np.ndarray:
    with rasterio.open(mask_path) as mask_src:
        if same_grid(src, mask_src):
            return mask_src.read(1, masked=False) > 0

        dst = np.zeros((src.height, src.width), dtype=np.uint8)
        reproject(
            source=rasterio.band(mask_src, 1),
            destination=dst,
            src_transform=mask_src.transform,
            src_crs=mask_src.crs,
            dst_transform=src.transform,
            dst_crs=src.crs,
            resampling=Resampling.nearest,
            src_nodata=mask_src.nodata,
            dst_nodata=0,
        )
        return dst > 0


def cell_xy_metric(
    rows: np.ndarray,
    cols: np.ndarray,
    transform: rasterio.Affine,
    transformer: Transformer,
) -> np.ndarray:
    xs, ys = rasterio.transform.xy(transform, rows, cols, offset="center")
    mx, my = transformer.transform(xs, ys)
    return np.column_stack([mx, my])


def fill_one(src_path: Path, mask_path: Path, variable: str, year: int, metric_crs) -> dict[str, object]:
    t0 = time.time()
    out_path = output_path(src_path)
    with rasterio.open(src_path) as src:
        arr = src.read(1, masked=False)
        profile = src.profile.copy()
        nodata = src.nodata
        transform = src.transform
        crs = src.crs
        study_mask = load_mask_for_source(src, mask_path)

    valid = raster_valid(arr, nodata)
    source = valid & study_mask
    target = (~valid) & study_mask
    filled = arr.copy()

    fill_count = 0
    max_distance_m = 0.0
    mean_distance_m = 0.0
    unresolved_after = int(target.sum())

    if target.any():
        source_n = int(source.sum())
        if source_n == 0:
            raise ValueError(f"No valid source cells inside study mask: {src_path}")

        transformer = Transformer.from_crs(crs, metric_crs, always_xy=True)
        rows_all, cols_all = np.indices(arr.shape, dtype=np.int32)
        src_rows = rows_all[source]
        src_cols = cols_all[source]
        tgt_rows = rows_all[target]
        tgt_cols = cols_all[target]

        tree = cKDTree(cell_xy_metric(src_rows, src_cols, transform, transformer))
        dist, idx = tree.query(cell_xy_metric(tgt_rows, tgt_cols, transform, transformer), k=1)
        filled[tgt_rows, tgt_cols] = arr[src_rows[idx], src_cols[idx]]

        fill_count = int(target.sum())
        max_distance_m = float(np.max(dist)) if dist.size else 0.0
        mean_distance_m = float(np.mean(dist)) if dist.size else 0.0
        unresolved_after = 0

    profile.update(
        driver="GTiff",
        compress="deflate",
        zlevel=9,
        tiled=True,
        BIGTIFF="IF_SAFER",
    )
    if np.issubdtype(filled.dtype, np.floating):
        profile.update(predictor=3)
    else:
        profile.update(predictor=2)

    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(filled, 1)

    final_valid = raster_valid(filled, nodata)
    return {
        "variable": variable,
        "year": year,
        "source_tif": str(src_path),
        "mask_tif": str(mask_path),
        "output_tif": str(out_path),
        "dtype": str(arr.dtype),
        "nodata": float(nodata) if nodata is not None else None,
        "width": int(arr.shape[1]),
        "height": int(arr.shape[0]),
        "study_mask_cells": int(study_mask.sum()),
        "valid_before_in_mask": int((valid & study_mask).sum()),
        "missing_before_in_mask": int(target.sum()),
        "filled_nearest": fill_count,
        "valid_after_in_mask": int((final_valid & study_mask).sum()),
        "missing_after_in_mask": int(((~final_valid) & study_mask).sum()),
        "unresolved_after": unresolved_after,
        "max_nearest_distance_m": max_distance_m,
        "mean_nearest_distance_m": mean_distance_m,
        "elapsed_sec": round(time.time() - t0, 2),
    }


def main() -> None:
    t0 = time.time()
    require_inputs()
    with rasterio.open(ALBERS_MASK) as mask_src:
        metric_crs = mask_src.crs

    reports: list[dict[str, object]] = []
    for dataset in DATASETS:
        variable = dataset["variable"]
        mask_path = dataset["mask"]
        for year in YEARS:
            src_path = dataset["path_func"](year)
            print(f"Filling {variable} {year}...", flush=True)
            reports.append(fill_one(src_path, mask_path, variable, year, metric_crs))

    report = {
        "method": (
            "Nearest-neighbor imputation for continuous environmental rasters. "
            "For each year and variable, source cells are valid pixels inside the matched coastal union mask; "
            "target cells are NoData pixels inside that mask. Nearest-neighbor distances are computed in the "
            "project Albers CRS. Pixels outside the study mask are left unchanged."
        ),
        "suffix": SUFFIX,
        "years": YEARS,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_sec": round(time.time() - t0, 2),
        "files": reports,
    }
    REPORT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(reports).to_csv(REPORT_CSV, index=False, encoding="utf-8-sig")
    print(f"Saved report: {REPORT_JSON}", flush=True)
    print(f"Saved report: {REPORT_CSV}", flush=True)
    print(f"Done in {(time.time() - t0) / 60:.2f} min", flush=True)


if __name__ == "__main__":
    main()
