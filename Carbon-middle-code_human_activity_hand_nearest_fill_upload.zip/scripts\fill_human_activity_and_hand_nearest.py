from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from scipy.spatial import cKDTree


BASE = Path("E:/1红树林蓝碳/数据")
PANEL_DIR = BASE / "yearly_panel_csv/coastal_1km_panel_2000_2024"
PANEL = PANEL_DIR / "coastal_1km_panel_2000_2024_with_age_weighted_carbon_ndvi_nn50km.parquet"
CACHE_DIR = PANEL_DIR / "cache_1km_arrays"
MASK_1KM = BASE / "气温/沿海土地利用25年并集掩膜/1km并集掩膜.tif"
HAND_SRC = BASE / "与最近河网的相对高度/HAND_1km_mean_from_30m_on_1km_union_mask_zlevel9.tif"

HUMAN_OUT_DIR = PANEL_DIR / "human_activity_intensity_nearest_filled_tif"
HUMAN_REPORT_CSV = PANEL_DIR / "human_activity_intensity_nearest_fill_report.csv"
HUMAN_REPORT_JSON = PANEL_DIR / "human_activity_intensity_nearest_fill_report.json"
HAND_REPORT_CSV = PANEL_DIR / "hand_nearest_fill_report.csv"
HAND_REPORT_JSON = PANEL_DIR / "hand_nearest_fill_report.json"

YEARS = list(range(2000, 2025))
NODATA = -9999.0


def raster_valid(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    valid = np.isfinite(arr)
    if nodata is not None and np.isfinite(float(nodata)):
        valid &= arr != nodata
    valid &= arr > -9000
    valid &= arr < 1.0e30
    return valid


def output_path(src: Path) -> Path:
    return src.with_name(f"{src.stem}_nearest_filled{src.suffix}")


def require_inputs() -> None:
    paths = [PANEL, MASK_1KM, HAND_SRC]
    paths.extend(CACHE_DIR / f"{year}_human_activity_intensity.npy" for year in YEARS)
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required input(s):\n" + "\n".join(map(str, missing)))


def xy_for_cells(transform: rasterio.Affine, rows: np.ndarray, cols: np.ndarray) -> np.ndarray:
    xs, ys = rasterio.transform.xy(transform, rows, cols, offset="center")
    return np.column_stack([xs, ys])


def nearest_fill_grid(
    arr: np.ndarray,
    study_mask: np.ndarray,
    transform: rasterio.Affine,
    nodata: float | int | None,
) -> tuple[np.ndarray, dict[str, float | int]]:
    filled = arr.copy()
    valid = raster_valid(filled, nodata)
    source = valid & study_mask
    target = (~valid) & study_mask
    rows_all, cols_all = np.indices(arr.shape, dtype=np.int32)

    stats: dict[str, float | int] = {
        "study_mask_cells": int(study_mask.sum()),
        "valid_before_in_mask": int(source.sum()),
        "missing_before_in_mask": int(target.sum()),
        "filled_nearest": 0,
        "valid_after_in_mask": int(source.sum()),
        "missing_after_in_mask": int(target.sum()),
        "max_nearest_distance_m": 0.0,
        "mean_nearest_distance_m": 0.0,
    }
    if not target.any():
        return filled, stats

    source_n = int(source.sum())
    if source_n == 0:
        raise ValueError("No valid source cells inside study mask.")

    src_rows = rows_all[source]
    src_cols = cols_all[source]
    tgt_rows = rows_all[target]
    tgt_cols = cols_all[target]
    tree = cKDTree(xy_for_cells(transform, src_rows, src_cols))
    dist, idx = tree.query(xy_for_cells(transform, tgt_rows, tgt_cols), k=1)
    filled[tgt_rows, tgt_cols] = arr[src_rows[idx], src_cols[idx]]

    final_valid = raster_valid(filled, nodata)
    stats.update(
        {
            "filled_nearest": int(target.sum()),
            "valid_after_in_mask": int((final_valid & study_mask).sum()),
            "missing_after_in_mask": int(((~final_valid) & study_mask).sum()),
            "max_nearest_distance_m": float(np.max(dist)) if dist.size else 0.0,
            "mean_nearest_distance_m": float(np.mean(dist)) if dist.size else 0.0,
        }
    )
    return filled, stats


def load_panel_base() -> pd.DataFrame:
    cols = ["year", "grid_id", "row", "col", "human_activity_intensity"]
    df = pd.read_parquet(PANEL, columns=cols, engine="pyarrow")
    base = df[df["year"] == 2000][["grid_id", "row", "col"]].copy()
    base["row"] = base["row"].astype(np.int32)
    base["col"] = base["col"].astype(np.int32)

    # Verify cached arrays use the same row order as the panel export.
    arr = np.load(CACHE_DIR / "2000_human_activity_intensity.npy")
    vals = df[df["year"] == 2000]["human_activity_intensity"].to_numpy()
    if not np.allclose(arr, vals, equal_nan=True):
        raise ValueError("Cached human_activity_intensity array order does not match panel year order.")
    return base


def write_float32_tif(path: Path, arr: np.ndarray, profile: dict) -> None:
    profile = profile.copy()
    profile.update(
        driver="GTiff",
        dtype="float32",
        count=1,
        nodata=NODATA,
        compress="deflate",
        zlevel=9,
        tiled=True,
        BIGTIFF="IF_SAFER",
        predictor=3,
    )
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(arr.astype(np.float32), 1)


def fill_human_activity() -> list[dict[str, object]]:
    HUMAN_OUT_DIR.mkdir(parents=True, exist_ok=True)
    with rasterio.open(MASK_1KM) as mask_src:
        mask = mask_src.read(1, masked=False) > 0
        profile = mask_src.profile.copy()
        transform = mask_src.transform
        height, width = mask_src.height, mask_src.width

    base = load_panel_base()
    reports: list[dict[str, object]] = []
    for year in YEARS:
        t0 = time.time()
        cache_path = CACHE_DIR / f"{year}_human_activity_intensity.npy"
        out_path = HUMAN_OUT_DIR / f"human_activity_intensity_{year}_1km_union_mask_nearest_filled.tif"
        values = np.load(cache_path).astype(np.float32)
        grid = np.full((height, width), NODATA, dtype=np.float32)
        valid_values = np.isfinite(values) & (values > -9000)
        grid[
            base.loc[valid_values, "row"].to_numpy(np.int64),
            base.loc[valid_values, "col"].to_numpy(np.int64),
        ] = values[valid_values]

        filled, stats = nearest_fill_grid(grid, mask, transform, NODATA)
        write_float32_tif(out_path, filled, profile)
        row = {
            "variable": "human_activity_intensity",
            "year": year,
            "source_cache": str(cache_path),
            "output_tif": str(out_path),
            "elapsed_sec": round(time.time() - t0, 2),
        }
        row.update(stats)
        reports.append(row)
        print(f"Filled human_activity_intensity {year}", flush=True)
    return reports


def fill_hand() -> dict[str, object]:
    t0 = time.time()
    with rasterio.open(HAND_SRC) as src:
        arr = src.read(1, masked=False).astype(np.float32)
        profile = src.profile.copy()
        transform = src.transform
        nodata = src.nodata
    with rasterio.open(MASK_1KM) as mask_src:
        mask = mask_src.read(1, masked=False) > 0
        if mask_src.width != arr.shape[1] or mask_src.height != arr.shape[0] or not mask_src.transform.almost_equals(transform):
            raise ValueError("HAND source raster does not match the 1 km union mask grid.")

    filled, stats = nearest_fill_grid(arr, mask, transform, nodata)
    out_path = output_path(HAND_SRC)
    profile.update(nodata=nodata if nodata is not None else NODATA)
    write_float32_tif(out_path, filled, profile)
    row = {
        "variable": "hand_m",
        "source_tif": str(HAND_SRC),
        "output_tif": str(out_path),
        "elapsed_sec": round(time.time() - t0, 2),
    }
    row.update(stats)
    print("Filled hand_m", flush=True)
    return row


def main() -> None:
    t0 = time.time()
    require_inputs()
    human_reports = fill_human_activity()
    hand_report = fill_hand()

    human_payload = {
        "method": (
            "Human activity intensity was restored from the panel cache arrays to the 1 km union mask grid, "
            "then filled by nearest neighbor inside the 1 km coastal union mask. Pixels outside the mask were left as NoData."
        ),
        "years": YEARS,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_sec": round(time.time() - t0, 2),
        "files": human_reports,
    }
    hand_payload = {
        "method": (
            "HAND was filled by nearest neighbor inside the 1 km coastal union mask using the existing 1 km HAND raster. "
            "Pixels outside the mask were left unchanged."
        ),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_sec": round(time.time() - t0, 2),
        "files": [hand_report],
    }
    HUMAN_REPORT_JSON.write_text(json.dumps(human_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(human_reports).to_csv(HUMAN_REPORT_CSV, index=False, encoding="utf-8-sig")
    HAND_REPORT_JSON.write_text(json.dumps(hand_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame([hand_report]).to_csv(HAND_REPORT_CSV, index=False, encoding="utf-8-sig")
    print(f"Saved report: {HUMAN_REPORT_JSON}", flush=True)
    print(f"Saved report: {HUMAN_REPORT_CSV}", flush=True)
    print(f"Saved report: {HAND_REPORT_JSON}", flush=True)
    print(f"Saved report: {HAND_REPORT_CSV}", flush=True)
    print(f"Done in {(time.time() - t0) / 60:.2f} min", flush=True)


if __name__ == "__main__":
    main()
