# Human Activity Intensity Nearest-Neighbor Fill

## Scope

Variable: `human_activity_intensity`

Years: 2000-2024

Output rasters: 25 annual 1 km GeoTIFFs.

## Input

The human activity intensity values were read from panel cache arrays:

`E:/1红树林蓝碳/数据/yearly_panel_csv/coastal_1km_panel_2000_2024/cache_1km_arrays/YYYY_human_activity_intensity.npy`

The cache arrays were verified against the panel column order for year 2000 before rasterization.
Each array has one value for each 1 km panel grid cell. The panel `row` and `col` fields were used
to restore each annual array to the 1 km coastal union mask grid.

Mask:

`E:/1红树林蓝碳/数据/气温/沿海土地利用25年并集掩膜/1km并集掩膜.tif`

## Method

For each year, valid source cells were defined as finite human activity intensity values inside the
1 km coastal union mask. Missing cells inside the same mask were filled with the nearest valid source
cell value. Nearest-neighbor distance was computed on the 1 km Albers grid. Pixels outside the study
mask were left as NoData.

## Output

Directory:

`E:/1红树林蓝碳/数据/yearly_panel_csv/coastal_1km_panel_2000_2024/human_activity_intensity_nearest_filled_tif`

Filename pattern:

`human_activity_intensity_YYYY_1km_union_mask_nearest_filled.tif`

## Summary

- Output files: 25
- Missing before fill: 323563
- Filled by nearest neighbor: 323563
- Missing after fill: 0
- Maximum nearest-neighbor distance: 31241.00 m
- Mean annual nearest-neighbor distance: 3063.43 m
