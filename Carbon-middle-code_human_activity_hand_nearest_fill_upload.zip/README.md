# Human Activity Intensity and HAND Nearest-Neighbor Fill

This folder records the nearest-neighbor filling for two remaining variables:

- `human_activity_intensity`
- `hand_m`

The processing notes are intentionally split into two files:

- `docs/human_activity_intensity_nearest_fill.md`
- `docs/hand_nearest_fill.md`

Large GeoTIFF outputs are not included in the repository package. Reports record the local output
paths, and the processing script can reproduce the outputs from the local data workspace.
