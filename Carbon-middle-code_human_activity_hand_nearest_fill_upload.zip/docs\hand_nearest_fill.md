# HAND Nearest-Neighbor Fill

## Scope

Variable: `hand_m`

Type: static 1 km HAND raster.

Output rasters: 1 GeoTIFF.

## Input

Source raster:

`E:/1红树林蓝碳/数据/与最近河网的相对高度/HAND_1km_mean_from_30m_on_1km_union_mask_zlevel9.tif`

Mask:

`E:/1红树林蓝碳/数据/气温/沿海土地利用25年并集掩膜/1km并集掩膜.tif`

## Method

Valid source cells were defined as finite HAND values inside the 1 km coastal union mask. Missing
cells inside the same mask were filled with the nearest valid source cell value. Since the source HAND
raster and the 1 km union mask share the same Albers grid, nearest-neighbor distance was computed
directly in meters. Pixels outside the study mask were left unchanged.

## Output

`E:/1红树林蓝碳/数据/与最近河网的相对高度/HAND_1km_mean_from_30m_on_1km_union_mask_zlevel9_nearest_filled.tif`

## Summary

- Study-mask cells: 134970
- Valid before fill: 127953
- Missing before fill: 7017
- Filled by nearest neighbor: 7017
- Missing after fill: 0
- Maximum nearest-neighbor distance: 28301.94 m
- Mean nearest-neighbor distance: 3262.21 m
