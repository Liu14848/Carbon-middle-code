# Coastal 30 m Land-Use Temporal Imputation

This note documents the imputation workflow for the 25 annual coastal land-use/land-cover rasters used in the mangrove blue-carbon panel.

## Purpose

The research target is mangrove conversion. Land-use classes are therefore not ordinary continuous covariates: they can be used both as predictors and to construct transition labels such as non-mangrove to mangrove. To avoid creating artificial conversion events, the imputation workflow distinguishes between:

- the original annual land-use observation;
- the imputed land-use value used as a covariate or map-completion product;
- an imputation flag raster that records how each value was obtained.

For mangrove conversion labels, use original observed land-use values whenever possible. If either the start year or the target year is missing in the original data, mark that transition sample as uncertain or exclude it from the main label construction.

## Input Data

Default annual input directory:

```text
E:\1红树林蓝碳\数据\沿海土地覆被图（10km缓冲）\土地利用图
```

Default file pattern:

```text
coastal_landuse_with_wetland_10km_fallback10km_{year}_albers.tif
```

Default years:

```text
2000-2024
```

Default 30 m union-mask template:

```text
E:\1红树林蓝碳\数据\气温\沿海土地利用25年并集掩膜\30m并集掩膜.tif
```

All outputs are aligned to the 30 m union-mask template. This matters because the 2023-2024 source rasters have a slightly different raster extent from the 2000-2022 rasters. The script reads each annual raster through a nearest-neighbor `WarpedVRT` on the template grid before imputation.

## Valid Classes

The script treats class codes 1-12 as valid and 0 as NoData/missing.

| Code | Class |
|---:|---|
| 1 | cropland |
| 2 | forest |
| 3 | shrubland |
| 4 | grassland |
| 5 | water |
| 6 | snow_ice |
| 7 | bare_land |
| 8 | impervious |
| 9 | wetland_other |
| 10 | tidal_flat |
| 11 | mangrove |
| 12 | salt_marsh |

## Imputation Rules

Imputation is done independently for each 30 m pixel's 25-year class trajectory.

| Case | Rule | Flag |
|---|---|---:|
| Original value is valid | Keep original value | 1 |
| Missing year is bracketed by the same class before and after | Fill with that class | 2 |
| Missing year has nearest valid previous class | Fill from previous year/class | 3 |
| Missing year has nearest valid next class | Fill from next year/class | 4 |
| No valid class exists in the 25-year trajectory inside the union mask | Keep NoData | 6 |

When the nearest previous and nearest next observations are equally distant but different, the script uses the previous observation as a deterministic tie-breaker and records the case under `filled_nearest_previous`. These conflict cases are also counted in `ambiguous_prev_next_differ`. If either side is mangrove, the case is counted in `ambiguous_mangrove_involved`.

This design completes the categorical map while preserving enough metadata to avoid using imputed values as if they were original observations.

## Output Data

Default output directory:

```text
E:\1红树林蓝碳\数据\沿海土地覆被图（10km缓冲）\土地利用图_时间序列填补30m
```

Filled annual land-use rasters:

```text
filled_landuse_tif\coastal_landuse_30m_temporal_filled_{year}_albers.tif
```

Annual imputation flag rasters:

```text
imputation_flag_tif\coastal_landuse_30m_temporal_imputation_flag_{year}_albers.tif
```

Reports:

```text
landuse_30m_temporal_imputation_report.json
landuse_30m_temporal_imputation_by_year.csv
landuse_30m_temporal_imputation_by_year_class.csv
```

## Run

From Anaconda Prompt:

```bat
cd /d C:\Users\libin\Documents\Codex\2026-07-13\019ea68f-0c68-72e0-91fc-208e3c4469aa\scripts
run_impute_coastal_landuse_30m_timeseries_anaconda.bat
```

Or call Python directly:

```bat
C:\ProgramData\anaconda3\python.exe impute_coastal_landuse_30m_timeseries.py --overwrite
```

For a quick smoke test:

```bat
C:\ProgramData\anaconda3\python.exe impute_coastal_landuse_30m_timeseries.py --overwrite --max-windows 5
```

## Recommended Use In The Mangrove Model

Use the filled land-use maps to derive covariates such as current land-use background or class composition. For the target variable "future conversion to mangrove", construct the main label from the original observed land-use maps. If the start or end year is missing in the original maps, exclude that sample from the main label set or mark it as uncertain. Then use the imputed version only for robustness checks.

This follows the common remote-sensing practice of using time-series consistency to complete noisy annual maps while keeping original observations and imputation uncertainty traceable.
