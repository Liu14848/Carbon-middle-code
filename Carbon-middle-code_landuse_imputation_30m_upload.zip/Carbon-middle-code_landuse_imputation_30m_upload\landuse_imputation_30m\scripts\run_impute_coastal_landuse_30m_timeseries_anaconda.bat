@echo off
setlocal

set PYTHON_EXE=C:\ProgramData\anaconda3\python.exe
set SCRIPT_DIR=%~dp0
set SCRIPT=%SCRIPT_DIR%impute_coastal_landuse_30m_timeseries.py

if not exist "%PYTHON_EXE%" (
  echo Python not found: %PYTHON_EXE%
  exit /b 1
)

"%PYTHON_EXE%" "%SCRIPT%" --overwrite
if errorlevel 1 (
  echo Failed.
  exit /b 1
)

echo Finished successfully.
