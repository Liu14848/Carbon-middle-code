# Carbon-middle-code upload package

This package contains the 30 m coastal land-use temporal imputation workflow for 2000-2024.

GitHub target repository:

```text
Liu14848/Carbon-middle-code
```

Suggested repository path:

```text
landuse_imputation_30m/
```

Contents:

- `scripts/impute_coastal_landuse_30m_timeseries.py`
- `scripts/run_impute_coastal_landuse_30m_timeseries_anaconda.bat`
- `docs/coastal_landuse_30m_temporal_imputation.md`
- `reports/landuse_30m_temporal_imputation_by_year.csv`
- `reports/landuse_30m_temporal_imputation_by_year_class.csv`
- `reports/landuse_30m_temporal_imputation_report.json`

Run status:

- Full 2000-2024 imputation completed successfully.
- 25 filled annual land-use GeoTIFFs were written locally.
- 25 annual imputation-flag GeoTIFFs were written locally.
- No original annual land-use rasters were overwritten.

Local output directory:

```text
E:\1红树林蓝碳\数据\沿海土地覆被图（10km缓冲）\土地利用图_时间序列填补30m
```
