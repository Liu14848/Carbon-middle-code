from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from rasterio.windows import Window


YEARS = list(range(2000, 2025))
VALID_CLASSES = np.arange(1, 13, dtype=np.uint16)
CLASS_NAMES = {
    1: "cropland",
    2: "forest",
    3: "shrubland",
    4: "grassland",
    5: "water",
    6: "snow_ice",
    7: "bare_land",
    8: "impervious",
    9: "wetland_other",
    10: "tidal_flat",
    11: "mangrove",
    12: "salt_marsh",
}

FLAG_NAMES = {
    0: "outside_union_or_unresolved",
    1: "original_observed",
    2: "filled_stable_bridge_prev_equals_next",
    3: "filled_nearest_previous",
    4: "filled_nearest_next",
    6: "unresolved_inside_union",
}

DEFAULT_INPUT_DIR = Path(r"E:\1红树林蓝碳\数据\沿海土地覆被图（10km缓冲）\土地利用图")
DEFAULT_INPUT_PATTERN = "coastal_landuse_with_wetland_10km_fallback10km_{year}_albers.tif"
DEFAULT_TEMPLATE_MASK = Path(r"E:\1红树林蓝碳\数据\气温\沿海土地利用25年并集掩膜\30m并集掩膜.tif")
DEFAULT_OUTPUT_DIR = Path(r"E:\1红树林蓝碳\数据\沿海土地覆被图（10km缓冲）\土地利用图_时间序列填补30m")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Impute 25-year coastal 30 m categorical land-use rasters with a "
            "same-pixel temporal consistency rule."
        )
    )
    parser.add_argument("--input-dir", type=Path, default=DEFAULT_INPUT_DIR)
    parser.add_argument("--input-pattern", default=DEFAULT_INPUT_PATTERN)
    parser.add_argument("--template-mask", type=Path, default=DEFAULT_TEMPLATE_MASK)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--years", nargs="*", type=int, default=YEARS)
    parser.add_argument("--block-size", type=int, default=512)
    parser.add_argument("--compress", default="DEFLATE", choices=["DEFLATE", "LZW"])
    parser.add_argument("--zlevel", type=int, default=9)
    parser.add_argument("--write-flags", action="store_true", default=True)
    parser.add_argument("--no-write-flags", action="store_false", dest="write_flags")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--max-windows",
        type=int,
        default=None,
        help="Debug option: process only the first N mask-intersecting windows.",
    )
    return parser.parse_args()


def annual_paths(input_dir: Path, input_pattern: str, years: list[int]) -> dict[int, Path]:
    paths = {}
    missing = []
    for year in years:
        path = input_dir / input_pattern.format(year=year)
        if path.exists():
            paths[year] = path
        else:
            missing.append(str(path))
    if missing:
        raise FileNotFoundError("Missing annual land-use rasters:\n" + "\n".join(missing))
    return paths


def iter_windows(width: int, height: int, block_size: int):
    for row_off in range(0, height, block_size):
        h = min(block_size, height - row_off)
        for col_off in range(0, width, block_size):
            w = min(block_size, width - col_off)
            yield Window(col_off, row_off, w, h)


def profile_for_output(mask_src, compress: str, zlevel: int, dtype: str, nodata: int):
    profile = mask_src.profile.copy()
    profile.update(
        driver="GTiff",
        dtype=dtype,
        count=1,
        nodata=nodata,
        tiled=True,
        blockxsize=512,
        blockysize=512,
        compress=compress,
        BIGTIFF="YES",
    )
    if compress.upper() == "DEFLATE":
        profile.update(zlevel=zlevel, predictor=1)
    return profile


def blank_stats(years: list[int]) -> dict[int, dict]:
    return {
        year: {
            "original_observed_inside_union": 0,
            "original_missing_inside_union": 0,
            "filled_stable_bridge_prev_equals_next": 0,
            "filled_nearest_previous": 0,
            "filled_nearest_next": 0,
            "unresolved_inside_union": 0,
            "ambiguous_prev_next_differ": 0,
            "ambiguous_mangrove_involved": 0,
            "filled_to_mangrove": 0,
            "original_class_counts": {str(c): 0 for c in VALID_CLASSES},
            "filled_class_counts": {str(c): 0 for c in VALID_CLASSES},
            "output_class_counts": {str(c): 0 for c in VALID_CLASSES},
        }
        for year in years
    }


def add_class_counts(target: dict[str, int], values: np.ndarray) -> None:
    if values.size == 0:
        return
    counts = np.bincount(values.astype(np.int16), minlength=13)
    for code in VALID_CLASSES:
        target[str(int(code))] += int(counts[int(code)])


def impute_stack(stack: np.ndarray, inside_union: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict]:
    """Return filled stack, per-year flags, and per-window stats.

    stack shape is (n_years, rows, cols), dtype uint16. Valid classes are 1..12.
    A value of 0 is treated as NoData/missing. Pixels outside inside_union are
    left as 0 and flagged 0.
    """

    n_years, rows, cols = stack.shape
    n_pixels = rows * cols
    stack2 = stack.reshape(n_years, n_pixels)
    inside = inside_union.reshape(n_pixels)
    valid = np.isin(stack2, VALID_CLASSES) & inside[None, :]

    filled = np.where(valid, stack2, 0).astype(np.uint16, copy=True)
    flags = np.zeros((n_years, n_pixels), dtype=np.uint8)
    flags[valid] = 1

    inf = np.int16(30000)
    prev_val = np.zeros((n_years, n_pixels), dtype=np.uint16)
    next_val = np.zeros((n_years, n_pixels), dtype=np.uint16)
    prev_dist = np.full((n_years, n_pixels), inf, dtype=np.int16)
    next_dist = np.full((n_years, n_pixels), inf, dtype=np.int16)

    last_val = np.zeros(n_pixels, dtype=np.uint16)
    last_dist = np.full(n_pixels, inf, dtype=np.int16)
    for i in range(n_years):
        has = valid[i]
        last_val[has] = stack2[i, has]
        last_dist[has] = 0
        prev_val[i] = last_val
        prev_dist[i] = last_dist
        can_age = last_dist < inf
        last_dist[can_age] += 1

    last_val.fill(0)
    last_dist.fill(inf)
    for i in range(n_years - 1, -1, -1):
        has = valid[i]
        last_val[has] = stack2[i, has]
        last_dist[has] = 0
        next_val[i] = last_val
        next_dist[i] = last_dist
        can_age = last_dist < inf
        last_dist[can_age] += 1

    stats = {
        "original_observed_inside_union": np.zeros(n_years, dtype=np.int64),
        "original_missing_inside_union": np.zeros(n_years, dtype=np.int64),
        "filled_stable_bridge_prev_equals_next": np.zeros(n_years, dtype=np.int64),
        "filled_nearest_previous": np.zeros(n_years, dtype=np.int64),
        "filled_nearest_next": np.zeros(n_years, dtype=np.int64),
        "unresolved_inside_union": np.zeros(n_years, dtype=np.int64),
        "ambiguous_prev_next_differ": np.zeros(n_years, dtype=np.int64),
        "ambiguous_mangrove_involved": np.zeros(n_years, dtype=np.int64),
        "filled_to_mangrove": np.zeros(n_years, dtype=np.int64),
        "original_values": [[] for _ in range(n_years)],
        "filled_values": [[] for _ in range(n_years)],
        "output_values": [[] for _ in range(n_years)],
    }

    for i in range(n_years):
        original = valid[i]
        missing = inside & ~valid[i]
        stats["original_observed_inside_union"][i] += int(original.sum())
        stats["original_missing_inside_union"][i] += int(missing.sum())
        stats["original_values"][i].append(stack2[i, original])

        if not missing.any():
            stats["output_values"][i].append(filled[i, inside & (filled[i] > 0)])
            continue

        p_avail = prev_dist[i] < inf
        n_avail = next_dist[i] < inf
        both = missing & p_avail & n_avail
        stable = both & (prev_val[i] == next_val[i])
        conflict = both & (prev_val[i] != next_val[i])
        mangrove_conflict = conflict & ((prev_val[i] == 11) | (next_val[i] == 11))

        use_prev = missing & ~stable & p_avail & (~n_avail | (prev_dist[i] <= next_dist[i]))
        use_next = missing & ~stable & n_avail & (~p_avail | (next_dist[i] < prev_dist[i]))
        unresolved = missing & ~(stable | use_prev | use_next)

        filled[i, stable] = prev_val[i, stable]
        flags[i, stable] = 2
        filled[i, use_prev] = prev_val[i, use_prev]
        flags[i, use_prev] = 3
        filled[i, use_next] = next_val[i, use_next]
        flags[i, use_next] = 4
        flags[i, unresolved] = 6

        filled_mask = stable | use_prev | use_next
        stats["filled_stable_bridge_prev_equals_next"][i] += int(stable.sum())
        stats["filled_nearest_previous"][i] += int(use_prev.sum())
        stats["filled_nearest_next"][i] += int(use_next.sum())
        stats["unresolved_inside_union"][i] += int(unresolved.sum())
        stats["ambiguous_prev_next_differ"][i] += int(conflict.sum())
        stats["ambiguous_mangrove_involved"][i] += int(mangrove_conflict.sum())
        stats["filled_to_mangrove"][i] += int((filled[i, filled_mask] == 11).sum())
        stats["filled_values"][i].append(filled[i, filled_mask])
        stats["output_values"][i].append(filled[i, inside & (filled[i] > 0)])

    return filled.reshape(n_years, rows, cols), flags.reshape(n_years, rows, cols), stats


def update_global_stats(global_stats: dict[int, dict], years: list[int], window_stats: dict) -> None:
    scalar_keys = [
        "original_observed_inside_union",
        "original_missing_inside_union",
        "filled_stable_bridge_prev_equals_next",
        "filled_nearest_previous",
        "filled_nearest_next",
        "unresolved_inside_union",
        "ambiguous_prev_next_differ",
        "ambiguous_mangrove_involved",
        "filled_to_mangrove",
    ]
    for i, year in enumerate(years):
        row = global_stats[year]
        for key in scalar_keys:
            row[key] += int(window_stats[key][i])
        for values in window_stats["original_values"][i]:
            add_class_counts(row["original_class_counts"], values)
        for values in window_stats["filled_values"][i]:
            add_class_counts(row["filled_class_counts"], values)
        for values in window_stats["output_values"][i]:
            add_class_counts(row["output_class_counts"], values)


def write_reports(output_dir: Path, years: list[int], stats: dict[int, dict], metadata: dict) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "landuse_30m_temporal_imputation_report.json"
    csv_path = output_dir / "landuse_30m_temporal_imputation_by_year.csv"
    class_csv_path = output_dir / "landuse_30m_temporal_imputation_by_year_class.csv"

    report = {
        "metadata": metadata,
        "flag_names": FLAG_NAMES,
        "class_names": CLASS_NAMES,
        "by_year": stats,
    }
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    fieldnames = [
        "year",
        "original_observed_inside_union",
        "original_missing_inside_union",
        "filled_total",
        "filled_stable_bridge_prev_equals_next",
        "filled_nearest_previous",
        "filled_nearest_next",
        "unresolved_inside_union",
        "ambiguous_prev_next_differ",
        "ambiguous_mangrove_involved",
        "filled_to_mangrove",
        "missing_fill_rate_pct",
    ]
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for year in years:
            row = stats[year]
            filled_total = (
                row["filled_stable_bridge_prev_equals_next"]
                + row["filled_nearest_previous"]
                + row["filled_nearest_next"]
            )
            missing = row["original_missing_inside_union"]
            writer.writerow(
                {
                    "year": year,
                    "original_observed_inside_union": row["original_observed_inside_union"],
                    "original_missing_inside_union": missing,
                    "filled_total": filled_total,
                    "filled_stable_bridge_prev_equals_next": row["filled_stable_bridge_prev_equals_next"],
                    "filled_nearest_previous": row["filled_nearest_previous"],
                    "filled_nearest_next": row["filled_nearest_next"],
                    "unresolved_inside_union": row["unresolved_inside_union"],
                    "ambiguous_prev_next_differ": row["ambiguous_prev_next_differ"],
                    "ambiguous_mangrove_involved": row["ambiguous_mangrove_involved"],
                    "filled_to_mangrove": row["filled_to_mangrove"],
                    "missing_fill_rate_pct": round(filled_total / missing * 100, 6) if missing else 100.0,
                }
            )

    with class_csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "year",
                "class_code",
                "class_name",
                "original_count",
                "filled_count",
                "output_count",
            ],
        )
        writer.writeheader()
        for year in years:
            row = stats[year]
            for code in VALID_CLASSES:
                code_str = str(int(code))
                writer.writerow(
                    {
                        "year": year,
                        "class_code": int(code),
                        "class_name": CLASS_NAMES[int(code)],
                        "original_count": row["original_class_counts"][code_str],
                        "filled_count": row["filled_class_counts"][code_str],
                        "output_count": row["output_class_counts"][code_str],
                    }
                )


def main() -> None:
    args = parse_args()
    years = args.years
    paths = annual_paths(args.input_dir, args.input_pattern, years)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    landuse_dir = args.output_dir / "filled_landuse_tif"
    flag_dir = args.output_dir / "imputation_flag_tif"
    landuse_dir.mkdir(parents=True, exist_ok=True)
    if args.write_flags:
        flag_dir.mkdir(parents=True, exist_ok=True)

    with rasterio.open(args.template_mask) as mask_src:
        width, height = mask_src.width, mask_src.height
        landuse_profile = profile_for_output(mask_src, args.compress, args.zlevel, "uint16", 0)
        flag_profile = profile_for_output(mask_src, args.compress, args.zlevel, "uint8", 0)

        out_paths = {
            year: landuse_dir / f"coastal_landuse_30m_temporal_filled_{year}_albers.tif"
            for year in years
        }
        flag_paths = {
            year: flag_dir / f"coastal_landuse_30m_temporal_imputation_flag_{year}_albers.tif"
            for year in years
        }
        existing = [str(p) for p in list(out_paths.values()) + list(flag_paths.values()) if p.exists()]
        if existing and not args.overwrite:
            raise FileExistsError(
                "Output files already exist. Use --overwrite to replace them.\n"
                + "\n".join(existing[:20])
            )

        srcs = [rasterio.open(paths[year]) for year in years]
        vrts = [
            WarpedVRT(
                src,
                crs=mask_src.crs,
                transform=mask_src.transform,
                width=width,
                height=height,
                resampling=Resampling.nearest,
                nodata=0,
                src_nodata=src.nodata if src.nodata is not None else 0,
                dtype="uint16",
            )
            for src in srcs
        ]
        out_datasets = [rasterio.open(out_paths[year], "w", **landuse_profile) for year in years]
        flag_datasets = []
        if args.write_flags:
            flag_datasets = [rasterio.open(flag_paths[year], "w", **flag_profile) for year in years]

        stats = blank_stats(years)
        processed_windows = 0
        skipped_windows = 0
        total_inside_pixels = 0

        try:
            for win_idx, window in enumerate(iter_windows(width, height, args.block_size), start=1):
                mask = mask_src.read(1, window=window)
                inside = mask == 1
                if not inside.any():
                    skipped_windows += 1
                    continue

                stack = np.stack([vrt.read(1, window=window, out_dtype="uint16") for vrt in vrts])
                filled, flags, window_stats = impute_stack(stack, inside)
                update_global_stats(stats, years, window_stats)
                total_inside_pixels += int(inside.sum())

                for i in range(len(years)):
                    out_datasets[i].write(filled[i], 1, window=window)
                    if args.write_flags:
                        flag_datasets[i].write(flags[i], 1, window=window)

                processed_windows += 1
                if processed_windows % 100 == 0:
                    print(
                        f"Processed {processed_windows} mask-intersecting windows "
                        f"(window index {win_idx}, inside pixels {total_inside_pixels:,}).",
                        flush=True,
                    )
                if args.max_windows is not None and processed_windows >= args.max_windows:
                    print(f"Stopped early after --max-windows={args.max_windows}.", flush=True)
                    break
        finally:
            for ds in flag_datasets:
                ds.close()
            for ds in out_datasets:
                ds.close()
            for vrt in vrts:
                vrt.close()
            for src in srcs:
                src.close()

        metadata = {
            "input_dir": str(args.input_dir),
            "input_pattern": args.input_pattern,
            "template_mask": str(args.template_mask),
            "output_dir": str(args.output_dir),
            "years": years,
            "valid_classes": [int(c) for c in VALID_CLASSES],
            "nodata": 0,
            "processed_mask_intersecting_windows": processed_windows,
            "skipped_empty_windows": skipped_windows,
            "total_inside_union_pixels_seen": total_inside_pixels,
            "note": (
                "Outputs are aligned to the 30 m union mask template. Annual source "
                "rasters that do not exactly match the template are read through a "
                "nearest-neighbor WarpedVRT before imputation."
            ),
        }
        write_reports(args.output_dir, years, stats, metadata)

    print(f"Finished. Reports written to: {args.output_dir}", flush=True)


if __name__ == "__main__":
    main()
