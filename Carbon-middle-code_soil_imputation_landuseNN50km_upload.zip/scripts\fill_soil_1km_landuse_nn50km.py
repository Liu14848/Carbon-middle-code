from __future__ import annotations

import json
import math
import time
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from scipy.spatial import cKDTree


BASE = Path("E:/1\u7ea2\u6811\u6797\u84dd\u78b3/\u6570\u636e")
PANEL = (
    BASE
    / "yearly_panel_csv/coastal_1km_panel_2000_2024/coastal_1km_panel_2000_2024.parquet"
)
MASK_1KM = BASE / "\u6c14\u6e29/\u6cbf\u6d77\u571f\u5730\u5229\u752825\u5e74\u5e76\u96c6\u63a9\u819c/1km\u5e76\u96c6\u63a9\u819c.tif"

SALINITY_DIR = BASE / "\u571f\u58e4\u76d0\u5ea6/1km\u6cbf\u6d77\u5e76\u96c6\u63a9\u819c\u88c1\u526a"
PH_0_30 = (
    BASE
    / "\u571f\u58e4pH/csdlv2_90m_pH_Hplus_weighted_0_30cm_1km_union_albers/"
    "CSDLv2_pH_Hplus_weighted_0_30cm_from_90m_on_1km_union_mask_zlevel9.tif"
)
PH_0_100 = (
    BASE
    / "\u571f\u58e4pH/csdlv2_90m_pH_Hplus_weighted_0_100cm_1km_union_albers/"
    "CSDLv2_pH_Hplus_weighted_0_100cm_from_90m_on_1km_union_mask_zlevel9.tif"
)
CLAY_0_30 = (
    BASE
    / "\u571f\u58e4\u9ecf\u7c92/csdlv2_90m_clay_0_30cm_percent_1km_union_albers/"
    "CSDLv2_Clay_0_30cm_percent_from_90m_on_1km_union_mask_zlevel9.tif"
)
CLAY_0_100 = (
    BASE
    / "\u571f\u58e4\u9ecf\u7c92/csdlv2_90m_clay_0_100cm_percent_1km_union_albers/"
    "CSDLv2_Clay_0_100cm_percent_from_90m_on_1km_union_mask_zlevel9.tif"
)

YEARS = list(range(2000, 2025))
MAX_DISTANCE_M = 50_000.0
SUFFIX = "_landuseNN50km_filled"
REPORT_JSON = BASE / "yearly_panel_csv/coastal_1km_panel_2000_2024/soil_landuse_nn50km_fill_report.json"
REPORT_CSV = BASE / "yearly_panel_csv/coastal_1km_panel_2000_2024/soil_landuse_nn50km_fill_report.csv"


def output_path(src: Path) -> Path:
    return src.with_name(f"{src.stem}{SUFFIX}{src.suffix}")


def require_inputs() -> None:
    paths = [PANEL, MASK_1KM, PH_0_30, PH_0_100, CLAY_0_30, CLAY_0_100]
    paths.extend(SALINITY_DIR / f"ECe_{year}_1km_union_mask_zlevel9.tif" for year in YEARS)
    missing = [p for p in paths if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required input(s):\n" + "\n".join(map(str, missing)))


def mode_ignore_nan(values: pd.Series) -> float:
    vals = values.dropna().to_numpy()
    if vals.size == 0:
        return np.nan
    counts = Counter(vals.tolist())
    return min(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0]


def load_panel_landuse(height: int, width: int) -> tuple[pd.DataFrame, dict[int, np.ndarray], np.ndarray]:
    cols = ["grid_id", "year", "row", "col", "landuse"]
    panel = pd.read_parquet(PANEL, columns=cols, engine="pyarrow")
    panel["row"] = panel["row"].astype(np.int32)
    panel["col"] = panel["col"].astype(np.int32)

    landuse_by_year: dict[int, np.ndarray] = {}
    for year in YEARS:
        grid = np.zeros((height, width), dtype=np.int16)
        sub = panel[panel["year"] == year]
        valid = sub["landuse"].notna()
        grid[
            sub.loc[valid, "row"].to_numpy(np.int64),
            sub.loc[valid, "col"].to_numpy(np.int64),
        ] = sub.loc[valid, "landuse"].to_numpy(np.int16)
        landuse_by_year[year] = grid

    dominant = panel.groupby("grid_id", sort=False)["landuse"].agg(mode_ignore_nan).reset_index()
    base = panel[panel["year"] == 2000][["grid_id", "row", "col"]].merge(dominant, on="grid_id", how="left")
    dominant_grid = np.zeros((height, width), dtype=np.int16)
    valid = base["landuse"].notna()
    dominant_grid[
        base.loc[valid, "row"].to_numpy(np.int64),
        base.loc[valid, "col"].to_numpy(np.int64),
    ] = base.loc[valid, "landuse"].to_numpy(np.int16)

    panel_base = panel[panel["year"] == 2000][["grid_id", "row", "col"]].copy()
    return panel_base, landuse_by_year, dominant_grid


def raster_valid(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    if np.issubdtype(arr.dtype, np.floating):
        valid = np.isfinite(arr)
        if nodata is not None and not math.isnan(float(nodata)):
            valid &= arr != nodata
        valid &= arr > -9000
        return valid
    if nodata is not None:
        return arr != np.array(nodata, dtype=arr.dtype)
    return np.ones(arr.shape, dtype=bool)


def classwise_fill(
    arr: np.ndarray,
    valid_mask: np.ndarray,
    target_mask: np.ndarray,
    landuse_grid: np.ndarray,
    transform: rasterio.Affine,
) -> tuple[np.ndarray, dict[str, object]]:
    filled = arr.copy()
    rows_all, cols_all = np.indices(arr.shape, dtype=np.int32)

    fill_count_same = 0
    fill_count_fallback = 0
    unresolved_same_no_source = 0
    unresolved_same_distance = 0
    max_dist_same = 0.0
    max_dist_fallback = 0.0
    per_class: list[dict[str, object]] = []

    classes = sorted(int(v) for v in np.unique(landuse_grid[target_mask]) if int(v) > 0)
    for cls in classes:
        cls_target = target_mask & (landuse_grid == cls)
        target_n = int(cls_target.sum())
        if target_n == 0:
            continue
        cls_source = valid_mask & (landuse_grid == cls)
        source_n = int(cls_source.sum())
        if source_n == 0:
            unresolved_same_no_source += target_n
            per_class.append(
                {
                    "landuse": cls,
                    "target_missing": target_n,
                    "source_valid": 0,
                    "filled_same_landuse": 0,
                    "unresolved_after_same_landuse": target_n,
                }
            )
            continue

        src_rows = rows_all[cls_source]
        src_cols = cols_all[cls_source]
        src_xy = np.column_stack(rasterio.transform.xy(transform, src_rows, src_cols, offset="center"))
        tree = cKDTree(src_xy)

        tgt_rows = rows_all[cls_target]
        tgt_cols = cols_all[cls_target]
        tgt_xy = np.column_stack(rasterio.transform.xy(transform, tgt_rows, tgt_cols, offset="center"))
        dist, idx = tree.query(tgt_xy, k=1, distance_upper_bound=MAX_DISTANCE_M)
        ok = np.isfinite(dist) & (idx < source_n)
        if ok.any():
            filled[tgt_rows[ok], tgt_cols[ok]] = arr[src_rows[idx[ok]], src_cols[idx[ok]]]
            fill_count_same += int(ok.sum())
            max_dist_same = max(max_dist_same, float(dist[ok].max()))
        not_ok = int((~ok).sum())
        unresolved_same_distance += not_ok
        per_class.append(
            {
                "landuse": cls,
                "target_missing": target_n,
                "source_valid": source_n,
                "filled_same_landuse": int(ok.sum()),
                "unresolved_after_same_landuse": not_ok,
                "max_same_landuse_distance_m": float(dist[ok].max()) if ok.any() else None,
            }
        )

    still_missing = target_mask & raster_valid(filled, None)
    still_missing = target_mask & (filled == arr)
    # Recompute unresolved targets robustly after same-landuse filling.
    still_missing = target_mask & ~raster_valid(filled, None)
    # The generic validity helper cannot know nodata after filling here, so derive from original target cells.
    still_missing = target_mask.copy()
    still_missing[target_mask] = filled[target_mask] == arr[target_mask]

    # Fallback only for target cells whose landuse was unavailable or whose same-landuse source was not within 50 km.
    fallback_target = still_missing
    if fallback_target.any():
        source = valid_mask
        source_n = int(source.sum())
        if source_n:
            src_rows = rows_all[source]
            src_cols = cols_all[source]
            src_xy = np.column_stack(rasterio.transform.xy(transform, src_rows, src_cols, offset="center"))
            tree = cKDTree(src_xy)
            tgt_rows = rows_all[fallback_target]
            tgt_cols = cols_all[fallback_target]
            tgt_xy = np.column_stack(rasterio.transform.xy(transform, tgt_rows, tgt_cols, offset="center"))
            dist, idx = tree.query(tgt_xy, k=1, distance_upper_bound=MAX_DISTANCE_M)
            ok = np.isfinite(dist) & (idx < source_n)
            if ok.any():
                filled[tgt_rows[ok], tgt_cols[ok]] = arr[src_rows[idx[ok]], src_cols[idx[ok]]]
                fill_count_fallback = int(ok.sum())
                max_dist_fallback = float(dist[ok].max())

    stats = {
        "target_missing_before": int(target_mask.sum()),
        "filled_same_landuse_nn50km": int(fill_count_same),
        "filled_fallback_any_landuse_nn50km": int(fill_count_fallback),
        "unresolved_same_no_source": int(unresolved_same_no_source),
        "unresolved_same_distance_over_50km": int(unresolved_same_distance),
        "max_same_landuse_distance_m": float(max_dist_same),
        "max_fallback_distance_m": float(max_dist_fallback),
        "per_landuse": per_class,
    }
    return filled, stats


def fill_one(src_path: Path, landuse_grid: np.ndarray, valid_panel_mask: np.ndarray, variable: str) -> dict[str, object]:
    out_path = output_path(src_path)
    t0 = time.time()
    with rasterio.open(src_path) as src:
        arr = src.read(1, masked=False)
        profile = src.profile.copy()
        nodata = src.nodata
        transform = src.transform

    valid = raster_valid(arr, nodata)
    source_valid = valid & valid_panel_mask
    target = (~valid) & valid_panel_mask
    filled, stats = classwise_fill(arr, source_valid, target, landuse_grid, transform)
    final_valid = raster_valid(filled, nodata)

    profile.update(
        driver="GTiff",
        compress="deflate",
        zlevel=9,
        tiled=True,
        BIGTIFF="IF_SAFER",
    )
    if np.issubdtype(filled.dtype, np.floating):
        profile.update(predictor=3)
    else:
        profile.update(predictor=2)

    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(filled, 1)

    stats.update(
        {
            "variable": variable,
            "source_tif": str(src_path),
            "output_tif": str(out_path),
            "dtype": str(arr.dtype),
            "nodata": float(nodata) if nodata is not None else None,
            "panel_cells": int(valid_panel_mask.sum()),
            "valid_before": int((valid & valid_panel_mask).sum()),
            "missing_before": int(target.sum()),
            "valid_after": int((final_valid & valid_panel_mask).sum()),
            "missing_after": int(((~final_valid) & valid_panel_mask).sum()),
            "elapsed_sec": round(time.time() - t0, 2),
        }
    )
    return stats


def main() -> None:
    t0 = time.time()
    require_inputs()
    with rasterio.open(MASK_1KM) as mask_src:
        valid_panel_mask = mask_src.read(1, masked=False) > 0
        height, width = mask_src.height, mask_src.width

    print("Loading 1 km panel landuse grids...", flush=True)
    _, landuse_by_year, dominant_landuse = load_panel_landuse(height, width)

    reports: list[dict[str, object]] = []
    for year in YEARS:
        src = SALINITY_DIR / f"ECe_{year}_1km_union_mask_zlevel9.tif"
        print(f"Filling soil salinity {year}...", flush=True)
        reports.append(fill_one(src, landuse_by_year[year], valid_panel_mask, f"soil_salinity_ece_{year}"))

    for variable, src in [
        ("soil_ph_0_30", PH_0_30),
        ("soil_ph_0_100", PH_0_100),
        ("soil_clay_0_30_percent", CLAY_0_30),
        ("soil_clay_0_100_percent", CLAY_0_100),
    ]:
        print(f"Filling {variable}...", flush=True)
        reports.append(fill_one(src, dominant_landuse, valid_panel_mask, variable))

    report = {
        "method": (
            "Nearest-neighbor imputation within 50 km. Primary match requires the same 1 km landuse "
            "class; cells without same-class source within 50 km fall back to any-landuse nearest "
            "neighbor within 50 km. Static pH and clay use the dominant 2000-2024 landuse class."
        ),
        "max_distance_m": MAX_DISTANCE_M,
        "suffix": SUFFIX,
        "panel": str(PANEL),
        "mask": str(MASK_1KM),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_sec": round(time.time() - t0, 2),
        "files": reports,
    }
    REPORT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    flat = []
    for item in reports:
        flat.append({k: v for k, v in item.items() if k != "per_landuse"})
    pd.DataFrame(flat).to_csv(REPORT_CSV, index=False, encoding="utf-8-sig")

    print(f"Saved report: {REPORT_JSON}", flush=True)
    print(f"Saved report: {REPORT_CSV}", flush=True)
    print(f"Done in {(time.time() - t0) / 60:.2f} min", flush=True)


if __name__ == "__main__":
    main()
