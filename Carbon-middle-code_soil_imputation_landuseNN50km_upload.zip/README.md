# 1 km soil variable imputation with landuse-constrained nearest neighbor

This folder records the 1 km soil raster imputation performed for the coastal mangrove panel.

## Method

Missing cells inside the 1 km coastal union panel mask were filled by nearest neighbor within 50 km.
The primary rule searches within the same 1 km landuse class. If no same-class valid source is found
within 50 km, the cell falls back to the nearest valid source from any landuse class within 50 km.

For annual soil salinity, the landuse class from the corresponding year is used. For static soil
pH, clay, alkaline nitrogen, and available phosphorus, the dominant 2000-2024 landuse class is used.

The scripts write new GeoTIFFs next to the original rasters using the suffix:

`_landuseNN50km_filled.tif`

Original rasters are not overwritten. Large GeoTIFF outputs are intentionally not stored in this
code repository; the reports record the local input and output paths.

## Scripts

- `scripts/fill_soil_1km_landuse_nn50km.py`: fills soil salinity, soil pH, and soil clay.
- `scripts/fill_soil_nutrients_1km_landuse_nn50km.py`: fills alkaline nitrogen and available phosphorus.

Both scripts require `numpy`, `pandas`, `pyarrow`, `rasterio`, and `scipy`.
They were run with `C:/ProgramData/anaconda3/python.exe`.

## Reports

- `reports/soil_landuse_nn50km_fill_report.csv`: file-level summary for soil salinity, pH, and clay.
- `reports/soil_nutrients_landuse_nn50km_fill_report.csv`: file-level summary for alkaline nitrogen and available phosphorus.
- `reports/soil_landuse_nn50km_fill_by_landuse.csv`: expanded landuse-class detail for salinity, pH, and clay.
- `reports/soil_nutrients_landuse_nn50km_fill_by_landuse.csv`: expanded landuse-class detail for nutrients.
- The JSON reports preserve the original nested output from the processing scripts.

## Completed outputs

- Soil salinity: 25 annual 1 km GeoTIFFs for 2000-2024.
- Soil pH: 0-30 cm and 0-100 cm GeoTIFFs.
- Soil clay: 0-30 cm and 0-100 cm GeoTIFFs.
- Alkaline nitrogen: 0-30 cm and 0-100 cm GeoTIFFs.
- Available phosphorus: 0-30 cm and 0-100 cm GeoTIFFs.

All processed variables have `missing_after = 0` inside the 1 km panel mask.
