from __future__ import annotations

import json
import math
import time
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from scipy.spatial import cKDTree


BASE = Path("E:/1红树林蓝碳/数据")
PANEL = (
    BASE
    / "yearly_panel_csv/coastal_1km_panel_2000_2024/coastal_1km_panel_2000_2024.parquet"
)
MASK_1KM = BASE / "气温/沿海土地利用25年并集掩膜/1km并集掩膜.tif"

ALKALINE_N_0_30 = (
    BASE
    / "碱解氮/csdlv2_90m_AN_0_30cm_mgkg_1km_union_albers/"
    "CSDLv2_AN_0_30cm_mgkg_from_90m_on_1km_union_mask_zlevel9.tif"
)
ALKALINE_N_0_100 = (
    BASE
    / "碱解氮/csdlv2_90m_AN_0_100cm_mgkg_1km_union_albers/"
    "CSDLv2_AN_0_100cm_mgkg_from_90m_on_1km_union_mask_zlevel9.tif"
)
AVAILABLE_P_0_30 = (
    BASE
    / "可用磷/csdlv2_90m_AP_0_30cm_mgkg_1km_union_albers/"
    "CSDLv2_AP_0_30cm_mgkg_from_90m_on_1km_union_mask_zlevel9.tif"
)
AVAILABLE_P_0_100 = (
    BASE
    / "可用磷/csdlv2_90m_AP_0_100cm_mgkg_1km_union_albers/"
    "CSDLv2_AP_0_100cm_mgkg_from_90m_on_1km_union_mask_zlevel9.tif"
)

YEARS = list(range(2000, 2025))
MAX_DISTANCE_M = 50_000.0
SUFFIX = "_landuseNN50km_filled"
REPORT_JSON = (
    BASE
    / "yearly_panel_csv/coastal_1km_panel_2000_2024/"
    "soil_nutrients_landuse_nn50km_fill_report.json"
)
REPORT_CSV = (
    BASE
    / "yearly_panel_csv/coastal_1km_panel_2000_2024/"
    "soil_nutrients_landuse_nn50km_fill_report.csv"
)


def output_path(src: Path) -> Path:
    return src.with_name(f"{src.stem}{SUFFIX}{src.suffix}")


def require_inputs() -> None:
    paths = [
        PANEL,
        MASK_1KM,
        ALKALINE_N_0_30,
        ALKALINE_N_0_100,
        AVAILABLE_P_0_30,
        AVAILABLE_P_0_100,
    ]
    missing = [p for p in paths if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required input(s):\n" + "\n".join(map(str, missing)))


def mode_ignore_nan(values: pd.Series) -> float:
    vals = values.dropna().to_numpy()
    if vals.size == 0:
        return np.nan
    counts = Counter(vals.tolist())
    return min(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0]


def load_dominant_landuse(height: int, width: int) -> np.ndarray:
    cols = ["grid_id", "year", "row", "col", "landuse"]
    panel = pd.read_parquet(PANEL, columns=cols, engine="pyarrow")
    panel["row"] = panel["row"].astype(np.int32)
    panel["col"] = panel["col"].astype(np.int32)
    panel = panel[panel["year"].isin(YEARS)]

    dominant = panel.groupby("grid_id", sort=False)["landuse"].agg(mode_ignore_nan).reset_index()
    base = panel[panel["year"] == 2000][["grid_id", "row", "col"]].merge(
        dominant, on="grid_id", how="left"
    )

    dominant_grid = np.zeros((height, width), dtype=np.int16)
    valid = base["landuse"].notna()
    dominant_grid[
        base.loc[valid, "row"].to_numpy(np.int64),
        base.loc[valid, "col"].to_numpy(np.int64),
    ] = base.loc[valid, "landuse"].to_numpy(np.int16)
    return dominant_grid


def raster_valid(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    if np.issubdtype(arr.dtype, np.floating):
        valid = np.isfinite(arr)
        if nodata is not None and np.isfinite(float(nodata)):
            valid &= arr != nodata
        valid &= arr > -9000
        valid &= arr < 1.0e30
        return valid
    if nodata is not None:
        return arr != np.array(nodata, dtype=arr.dtype)
    return np.ones(arr.shape, dtype=bool)


def xy_for_cells(transform: rasterio.Affine, rows: np.ndarray, cols: np.ndarray) -> np.ndarray:
    xs, ys = rasterio.transform.xy(transform, rows, cols, offset="center")
    return np.column_stack([xs, ys])


def classwise_fill(
    arr: np.ndarray,
    valid_mask: np.ndarray,
    target_mask: np.ndarray,
    landuse_grid: np.ndarray,
    transform: rasterio.Affine,
) -> tuple[np.ndarray, dict[str, object]]:
    filled = arr.copy()
    unresolved = target_mask.copy()
    rows_all, cols_all = np.indices(arr.shape, dtype=np.int32)

    fill_count_same = 0
    fill_count_fallback = 0
    unresolved_same_no_source = 0
    unresolved_same_distance = 0
    max_dist_same = 0.0
    max_dist_fallback = 0.0
    per_class: list[dict[str, object]] = []

    classes = sorted(int(v) for v in np.unique(landuse_grid[target_mask]) if int(v) > 0)
    for cls in classes:
        cls_target = target_mask & (landuse_grid == cls)
        target_n = int(cls_target.sum())
        if target_n == 0:
            continue

        cls_source = valid_mask & (landuse_grid == cls)
        source_n = int(cls_source.sum())
        if source_n == 0:
            unresolved_same_no_source += target_n
            per_class.append(
                {
                    "landuse": cls,
                    "target_missing": target_n,
                    "source_valid": 0,
                    "filled_same_landuse": 0,
                    "unresolved_after_same_landuse": target_n,
                }
            )
            continue

        src_rows = rows_all[cls_source]
        src_cols = cols_all[cls_source]
        tree = cKDTree(xy_for_cells(transform, src_rows, src_cols))

        tgt_rows = rows_all[cls_target]
        tgt_cols = cols_all[cls_target]
        dist, idx = tree.query(
            xy_for_cells(transform, tgt_rows, tgt_cols),
            k=1,
            distance_upper_bound=MAX_DISTANCE_M,
        )
        ok = np.isfinite(dist) & (idx < source_n)
        if ok.any():
            filled[tgt_rows[ok], tgt_cols[ok]] = arr[src_rows[idx[ok]], src_cols[idx[ok]]]
            unresolved[tgt_rows[ok], tgt_cols[ok]] = False
            fill_count_same += int(ok.sum())
            max_dist_same = max(max_dist_same, float(dist[ok].max()))

        not_ok = int((~ok).sum())
        unresolved_same_distance += not_ok
        per_class.append(
            {
                "landuse": cls,
                "target_missing": target_n,
                "source_valid": source_n,
                "filled_same_landuse": int(ok.sum()),
                "unresolved_after_same_landuse": not_ok,
                "max_same_landuse_distance_m": float(dist[ok].max()) if ok.any() else None,
            }
        )

    if unresolved.any():
        source_n = int(valid_mask.sum())
        if source_n:
            src_rows = rows_all[valid_mask]
            src_cols = cols_all[valid_mask]
            tree = cKDTree(xy_for_cells(transform, src_rows, src_cols))

            tgt_rows = rows_all[unresolved]
            tgt_cols = cols_all[unresolved]
            dist, idx = tree.query(
                xy_for_cells(transform, tgt_rows, tgt_cols),
                k=1,
                distance_upper_bound=MAX_DISTANCE_M,
            )
            ok = np.isfinite(dist) & (idx < source_n)
            if ok.any():
                filled[tgt_rows[ok], tgt_cols[ok]] = arr[src_rows[idx[ok]], src_cols[idx[ok]]]
                unresolved[tgt_rows[ok], tgt_cols[ok]] = False
                fill_count_fallback = int(ok.sum())
                max_dist_fallback = float(dist[ok].max())

    stats = {
        "target_missing_before": int(target_mask.sum()),
        "filled_same_landuse_nn50km": int(fill_count_same),
        "filled_fallback_any_landuse_nn50km": int(fill_count_fallback),
        "unresolved_same_no_source": int(unresolved_same_no_source),
        "unresolved_same_distance_over_50km": int(unresolved_same_distance),
        "unresolved_after_fallback": int(unresolved.sum()),
        "max_same_landuse_distance_m": float(max_dist_same),
        "max_fallback_distance_m": float(max_dist_fallback),
        "per_landuse": per_class,
    }
    return filled, stats


def fill_one(src_path: Path, landuse_grid: np.ndarray, valid_panel_mask: np.ndarray, variable: str) -> dict[str, object]:
    out_path = output_path(src_path)
    t0 = time.time()
    with rasterio.open(src_path) as src:
        arr = src.read(1, masked=False)
        profile = src.profile.copy()
        nodata = src.nodata
        transform = src.transform

    valid = raster_valid(arr, nodata)
    source_valid = valid & valid_panel_mask
    target = (~valid) & valid_panel_mask
    filled, stats = classwise_fill(arr, source_valid, target, landuse_grid, transform)
    final_valid = raster_valid(filled, nodata)

    profile.update(
        driver="GTiff",
        compress="deflate",
        zlevel=9,
        tiled=True,
        BIGTIFF="IF_SAFER",
    )
    if np.issubdtype(filled.dtype, np.floating):
        profile.update(predictor=3)
    else:
        profile.update(predictor=2)

    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(filled, 1)

    stats.update(
        {
            "variable": variable,
            "source_tif": str(src_path),
            "output_tif": str(out_path),
            "dtype": str(arr.dtype),
            "nodata": float(nodata) if nodata is not None else None,
            "panel_cells": int(valid_panel_mask.sum()),
            "valid_before": int((valid & valid_panel_mask).sum()),
            "missing_before": int(target.sum()),
            "valid_after": int((final_valid & valid_panel_mask).sum()),
            "missing_after": int(((~final_valid) & valid_panel_mask).sum()),
            "elapsed_sec": round(time.time() - t0, 2),
        }
    )
    return stats


def main() -> None:
    t0 = time.time()
    require_inputs()
    with rasterio.open(MASK_1KM) as mask_src:
        valid_panel_mask = mask_src.read(1, masked=False) > 0
        height, width = mask_src.height, mask_src.width

    print("Loading dominant 2000-2024 landuse grid...", flush=True)
    dominant_landuse = load_dominant_landuse(height, width)

    reports: list[dict[str, object]] = []
    for variable, src in [
        ("alkaline_n_0_30_mgkg", ALKALINE_N_0_30),
        ("alkaline_n_0_100_mgkg", ALKALINE_N_0_100),
        ("available_p_0_30_mgkg", AVAILABLE_P_0_30),
        ("available_p_0_100_mgkg", AVAILABLE_P_0_100),
    ]:
        print(f"Filling {variable}...", flush=True)
        reports.append(fill_one(src, dominant_landuse, valid_panel_mask, variable))

    report = {
        "method": (
            "Nearest-neighbor imputation within 50 km for static soil nutrient rasters. "
            "Primary match requires the same dominant 2000-2024 1 km landuse class; cells without "
            "same-class source within 50 km fall back to any-landuse nearest neighbor within 50 km."
        ),
        "max_distance_m": MAX_DISTANCE_M,
        "suffix": SUFFIX,
        "panel": str(PANEL),
        "mask": str(MASK_1KM),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_sec": round(time.time() - t0, 2),
        "files": reports,
    }
    REPORT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame([{k: v for k, v in item.items() if k != "per_landuse"} for item in reports]).to_csv(
        REPORT_CSV, index=False, encoding="utf-8-sig"
    )

    print(f"Saved report: {REPORT_JSON}", flush=True)
    print(f"Saved report: {REPORT_CSV}", flush=True)
    print(f"Done in {(time.time() - t0) / 60:.2f} min", flush=True)


if __name__ == "__main__":
    main()
